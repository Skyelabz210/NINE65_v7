# Checked Scalar Refresh in NINE65

This package contains the editable source and data for the nine-page implementation paper dated 24 November 2026. It describes the trusted-key scalar refresh implementation at `48f5012480f53005aa288bdb9ede1fa944cba904`, submitted in [NINE65 PR 207](https://github.com/Skyelabz210/NINE65_v7/pull/207).

## Contents

- `refresh_paper.tex` is the editable LaTeX source.
- `refresh_paper.pdf` is the compiled paper.
- `figures/paired_timings.pdf` and `.svg` are vector exports of the timing figure. A PNG is also included.
- `data/secure_128.csv` contains the 21 original paired measurements.
- `data/summary.json` contains statistics recomputed from that CSV.
- `data/source_manifest.json` binds the inspected repository files to their SHA-256 hashes and records the parameter tuple.
- `make_figure.py` regenerates the timing figure and statistics.
- `SHA256SUMS` records the hashes of the package contents.

## Rebuild

The figure PDF is included, so recompiling the paper requires a standard LaTeX installation with `latexmk` and the packages named in the preamble.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error refresh_paper.tex
```

To regenerate the figure, use Python 3 with NumPy and Matplotlib.

```sh
python3 make_figure.py
latexmk -pdf -interaction=nonstopmode -halt-on-error refresh_paper.tex
```

## Figure and evidence checks

The paper contains one two-panel timing figure. The local statistical-visualization pass used all 21 rows, retained the extreme observations, linked matched rounds, and supplemented color with distinct marker shapes. Axis labels state the units and logarithmic scales. Panel-specific ranges are stated in the caption. Dark bars identify medians.

The final PDF was checked for unresolved references, missing figures, overfull boxes and text outside page boundaries. Its source links use the full reviewed commit. The source manifest was compared with committed repository bytes. Timing summaries and the two algebraic derivations were checked independently against the saved CSV and reduced integer examples.

The execution section describes the Rust tests already run during implementation. Preparing this paper recomputed the statistics and checked the artifact against the source. The paper includes mathematical arguments and explicitly records the scope of the executed tests and remaining security obligations.

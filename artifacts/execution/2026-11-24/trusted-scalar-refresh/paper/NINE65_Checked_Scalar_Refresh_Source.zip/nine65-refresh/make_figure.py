"""Regenerate the paired timing figure and machine-readable summary.

Local visualization brief
  Owner: paper author, local statistical visualization pass.
  Job: show all matched measurements alongside the reported medians.
  Data: 21 CSV rows, two timing comparisons in milliseconds.
  Encoding: matched rounds linked by gray lines, circles for the reference,
    squares for the scalar path, logarithmic y axes, medians as dark bars.
  Accessibility: distinct shapes and direct category labels supplement color.
  QA: no filtering, no outlier removal, numerical medians recomputed from CSV.
  Exports: vector PDF and SVG plus PNG for inspection and office embedding.
"""

import csv
import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/nine65-paper-matplotlib")
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
with (ROOT / "data/secure_128.csv").open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 21
assert [int(row["round"]) for row in rows] == list(range(1, 22))

pairs = [
    ("Coefficient-zero decode", "full_decode_ns", "scalar_decode_ns"),
    ("Public-key refresh\n(decode and re-encrypt)", "full_refresh_ns", "scalar_refresh_ns"),
]
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
    }
)
fig, axes = plt.subplots(1, 2, figsize=(6.5, 3.0))
summary = {"sample_count": len(rows), "unit": "ms", "operations": {}}
for ax, (title, ref_key, scalar_key) in zip(axes, pairs):
    ref = np.array([int(row[ref_key]) for row in rows]) / 1e6
    scalar = np.array([int(row[scalar_key]) for row in rows]) / 1e6
    offset = np.linspace(-0.095, 0.095, len(rows))
    for left, right, dx in zip(ref, scalar, offset):
        ax.plot([dx, 1 + dx], [left, right], color="#9EA6AB", alpha=0.45, lw=0.6)
    ax.scatter(offset, ref, color="#2B4C7E", marker="o", s=15, zorder=3)
    ax.scatter(1 + offset, scalar, color="#007E80", marker="s", s=15, zorder=3)
    for x, data in [(0, ref), (1, scalar)]:
        med = float(np.median(data))
        ax.plot([x - 0.17, x + 0.17], [med, med], color="#171D22", lw=2, zorder=4)
        ax.annotate(
            f"{med:.3f} ms",
            xy=(x, med),
            xytext=(0, -18),
            textcoords="offset points",
            ha="center",
            fontsize=8,
            color="#171D22",
        )
    ax.set_yscale("log")
    ax.set_xlim(-0.35, 1.35)
    ax.set_xticks([0, 1], ["Full product", "Checked scalar"])
    ax.set_title(title, pad=12)
    ax.set_ylabel("Elapsed time (ms, log scale)")
    ax.grid(axis="y", which="major", color="#DDE1E4", lw=0.6)
    ax.set_axisbelow(True)
    ax.tick_params(which="minor", labelleft=False)
    summary["operations"][ref_key] = {
        "min_ms": float(ref.min()),
        "q25_ms": float(np.quantile(ref, 0.25)),
        "median_ms": float(np.median(ref)),
        "q75_ms": float(np.quantile(ref, 0.75)),
        "max_ms": float(ref.max()),
    }
    summary["operations"][scalar_key] = {
        "min_ms": float(scalar.min()),
        "q25_ms": float(np.quantile(scalar, 0.25)),
        "median_ms": float(np.median(scalar)),
        "q75_ms": float(np.quantile(scalar, 0.75)),
        "max_ms": float(scalar.max()),
    }
    ax.annotate(
        "round 15",
        xy=(offset[14], ref[14]) if ref_key == "full_decode_ns" else (1 + offset[14], scalar[14]),
        xytext=(-8, 9),
        textcoords="offset points",
        ha="center",
        fontsize=7,
    )

axes[0].set_ylim(0.06, 140)
axes[1].set_ylim(19, 100)
axes[1].set_yticks([20, 30, 50, 100], ["20", "30", "50", "100"])
axes[1].yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
fig.subplots_adjust(left=0.085, right=0.99, bottom=0.18, top=0.84, wspace=0.36)
for ext in ["pdf", "svg", "png"]:
    fig.savefig(ROOT / f"figures/paired_timings.{ext}", dpi=180)
plt.close(fig)

full_decode = summary["operations"]["full_decode_ns"]["median_ms"]
scalar_decode = summary["operations"]["scalar_decode_ns"]["median_ms"]
full_refresh = summary["operations"]["full_refresh_ns"]["median_ms"]
scalar_refresh = summary["operations"]["scalar_refresh_ns"]["median_ms"]
summary["median_decode_speedup"] = full_decode / scalar_decode
summary["median_refresh_reduction_pct"] = 100 * (1 - scalar_refresh / full_refresh)
summary["paired_refresh_wins"] = sum(int(row["scalar_refresh_ns"]) < int(row["full_refresh_ns"]) for row in rows)
(ROOT / "data/summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))

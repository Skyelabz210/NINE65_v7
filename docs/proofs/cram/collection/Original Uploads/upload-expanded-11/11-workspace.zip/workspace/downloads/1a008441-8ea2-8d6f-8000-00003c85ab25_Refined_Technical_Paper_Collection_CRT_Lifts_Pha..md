# Refined Technical Paper Collection: CRT Lifts, Phase Locking, and Capacity-Safe Elimination

**Prepared for:** Anthony Diaz (Acid)  
**Scope:** Consolidation of the supplied CRT, star-lift, hidden-carry, trajectory-winding, and arrow-of-time materials, together with the formal results developed in this session.  
**Status:** Research-grade technical drafts. Every theorem below is limited to its stated hypotheses; no claim of physical realization, cryptographic security, or universal dynamical irreversibility is made without a separate proof.

## Collection map

| Paper | Core contribution | Mathematical status | Why it warrants a separate paper |
|---|---|---|---|
| [01](01_covering_coordinate_and_trajectory_winding.md) | A covering-space and torus formulation of residue-plus-quotient trajectories | Exact theorem under an explicit path/lift convention | It cleanly separates a genuine trajectory winding from a static quotient coordinate and establishes the rank-one constraint on scalar CRT trajectories. |
| [02](02_star_lift_elimination_contract.md) | The 36/37 star-lift as a bounded, elimination-only quotient-recovery primitive | Exact arithmetic theorem with a finite capacity contract | The special self-inverse relation produces a subtraction-only fast path and makes the finite-information boundary explicit. |
| [03](03_phase_locked_transduction.md) | A dynamic invariant for phase-locked heterogeneous residue lanes | Exact invariant and update-preservation theorem | It gives a testable specification for lane-wise transduction, rather than treating cross-lane coupling as an analogy. |
| [04](04_anchor_ladder_capacity_overflow.md) | Anchor-ladder capacity scaling, certified recovery, and overflow signaling | Exact information-capacity and state-machine theorems | It provides a safe elimination-first architecture and proves why fixed residues alone cannot detect overflow. |

## Shared notation

Let \(M\ge2\). Every integer \(X\) has a unique division-algorithm decomposition

\[
X=MK+r,
\qquad 0\le r<M,
\qquad K=\left\lfloor\frac XM\right\rfloor
\]

for \(X\ge0\). The collection calls \(r\) the **phase** and \(K\) the **lift coordinate** or, when a path is present, the **sheet coordinate**. This language is compatible with the covering map from the integer line to the finite cycle, but the word “winding” is reserved carefully:

> A static pair \((r,K)\) is an arithmetic lift coordinate. A topological winding number is obtained only after a trajectory, a lift, and a closed projected path have been specified.

For pairwise-coprime moduli \(m_1,\ldots,m_k\), write

\[
M=\prod_{i=1}^{k}m_i.
\]

The CRT residue map is

\[
\rho(X)=(X\bmod m_1,\ldots,X\bmod m_k).
\]

## Evidence and validation boundary

The supplied `starlift.py` was executed successfully. It confirms the exact 36/37 relation, validates anchor-ladder recovery over stated finite ranges, and explicitly checks the single-anchor ambiguity. The independent validation file included with this collection verifies the four core results used by the papers: bounded 36/37 recovery, ladder recovery below capacity, phase-lock preservation under signed additive steps, CRT torus winding for closed trajectories, and epoch-based overflow accounting.

The historical RNS literature already contains redundant-modulus base extension without a traditional mixed-radix conversion cascade.[1] The papers therefore do **not** claim novelty for CRT itself, quotient recovery itself, or the mere avoidance of Garner conversion. The contributions articulated here are the special 36/37 capacity contract, the trajectory-level topological formulation, the phase-lock invariant for transduction, and the capacity-safe overflow protocol.

## Source files in the supplied corpus

| Identifier | Supplied source | Role in this collection |
|---|---|---|
| D-030 | `TheIdentityofaNumberD-030.md` and PDF rendering | Original residue/winding thesis and K-elimination formulation |
| HC | `Hidden_Carry_Formalization_DRAFT.md` | Exact signed-carry identity, finite-scope arrow discussion, and stated open problems |
| SL | `starlift.py` | 36/37 specialization, star-prime ladder, and executable verification ledger |
| AF | `arrow_paper.pdf` | Covering-line orientation, reversible successor, quotient-based information loss |
| CF | `carry_functional.rs` | Centered-residue convention and lift-energy functional |
| CRT | `CRT_Foundations_Applications_CRAM_Divergence.docx` | Background CRT/RNS context and Garner discussion |

## References

[1] [A. P. Shenoy and R. Kumaresan, “Fast Base Extension Using a Redundant Modulus in RNS,” *IEEE Transactions on Computers* 38(2), 292–297 (1989)](https://digitalcommons.uri.edu/ele_facpubs/710/). The archival abstract states that the method performs base extension using CRT and a redundant modulus without traditional mixed-radix conversion.

[2] [M. Selianinau and Y. Povstenko, “An Efficient Parallel Reverse Conversion of Residue Code to Mixed-Radix Representation Based on the Chinese Remainder Theorem,” *Entropy* 24(2):242 (2022)](https://pmc.ncbi.nlm.nih.gov/articles/PMC8871111/).

[3] [M. Selianinau and Y. Povstenko, “An Efficient CRT-Base Power-of-Two Scaling in Minimally Redundant Residue Number System,” *Entropy* 24(12):1824 (2022)](https://pmc.ncbi.nlm.nih.gov/articles/PMC9777657/).

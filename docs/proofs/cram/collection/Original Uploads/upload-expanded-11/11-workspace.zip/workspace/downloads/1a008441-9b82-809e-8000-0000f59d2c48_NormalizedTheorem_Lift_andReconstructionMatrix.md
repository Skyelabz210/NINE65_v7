# Normalized Theorem, Lift, and Reconstruction Matrix

## Status vocabulary

| Code | Meaning in this matrix |
|---|---|
| **CORE-PROVEN** | An exact theorem or directly verified finite algorithm admitted to the threaded normative kernel. |
| **CORE-CONDITIONAL** | Exact only after a stated range, capacity, authenticity, or inverse condition is supplied. |
| **BOUNDARY** | Exact only as a read-only diagnostic, materialization, or externally certified transition; not an arithmetic-core instruction. |
| **ARCHITECTURAL** | A defined implementation pattern that requires compatibility and conformance proofs to be core-admissible. |
| **HISTORICAL / RETIRED** | Retained for provenance, proof reference, test oracle, or boundary use, but prohibited on the runtime core path. |
| **OPEN** | A research, formalization, security, or application claim not established by the normative kernel. |

## A. Fundamental representation and lift theorems

| ID | Statement | Hypotheses | Output / guarantee | Cost model | Status |
|---|---|---|---|---|---|
| T1 | **Fixed-frame residue–lift bijection:** `nu_B(r,K)=gamma_B(r)+M_BK`. | Pairwise-coprime fixed frame `B`; `K in Z`. | A one-to-one coordinate for every integer. | Representation identity; `gamma_B` is not required in the hot path. | CORE-PROVEN |
| T2 | **Single-modulus division lift:** `X=r_M(X)+M K_M(X)`. | `M>=2`; least-nonnegative residue section. | Exact residue plus sheet coordinate. | O(1) word arithmetic if `K_M` is stored. | CORE-PROVEN |
| T3 | **Canonical trajectory lift:** `X_t/M` lifts the residue path. | Time-indexed integer trajectory and canonical linear interpolation. | A well-defined covering lift. | O(1) state update per scalar step. | CORE-CONDITIONAL |
| T4 | **Closed-path winding:** `wind=K_T-K_0=(X_T-X_0)/M`. | T3 and equal endpoint residues. | The quotient-coordinate difference is a genuine path winding. | O(1) endpoint calculation. | CORE-CONDITIONAL |
| T5 | **Constrained CRT-torus winding:** `W=ell(M/m_1,...,M/m_k)`. | Pairwise-coprime frame and scalar trajectory closure. | Scalar trajectories form a rank-one sublattice, not arbitrary `Z^k` lane windings. | O(k) to report vector. | CORE-PROVEN |
| T6 | **Forward carry accumulation:** `Delta K_t=(r_t+delta_t-r_{t+1})/M`. | Integer additive update; nonnegative monotonicity additionally requires forward-orientation constraints. | Exact signed lift increment / carry. | O(1). | CORE-PROVEN; monotonicity only CORE-CONDITIONAL |

## B. K-Elimination theorem family

| ID | Statement | Required authentic state | Capacity / domain | Output | Runtime arithmetic | Status |
|---|---|---|---|---|---|---|
| K1 | **Generic anchor elimination:** `kappa_A=(r_A-r_M)M^{-1} mod A=K mod A`. | Direct residues `r_M=X mod M`, `r_A=X mod A`; `gcd(M,A)=1`. | No full `K` unless `0<=K<A` is certified. | An anchor observation of the lift. | Subtraction + fixed modular inverse multiplication. | CORE-PROVEN |
| K2 | **Consecutive-pair collapse:** `K mod(n+1)=(r_n-r_(n+1)) mod(n+1)`. | Authentic residues for the fixed pair `(n,n+1)`. | Exact `K` only for `0<=K<n+1`. | Lift residue under the adjacent anchor. | One modular subtraction. | CORE-PROVEN |
| K3 | **36/37 StarLift collapse:** `kappa_37=(r_36-r_37) mod37`. | Static authentic shell `36` and anchor `37`. | Exact number only for `0<=K<37`, i.e. `0<=X<1332`. | `K mod37`; bounded full reconstruction under certificate. | One fixed-width subtract-and-normalize. | CORE-PROVEN congruence; CORE-CONDITIONAL materialization |
| K4 | **Ladder recovery:** `Khat=K mod C`, `C=prod A_j`. | Static mutually coprime authentic anchors; each coprime to `M`. | Exact iff `0<=K<C`. | Wider lift representative. | Per-anchor K1 plus offline/boundary CRT merge or a separately certified fixed tree. | CORE-CONDITIONAL |
| K5 | **Epoch unwrapping:** `K=Q C+Khat`. | K4 state plus retained signed epoch `Q`. | No finite range limit if epoch updates are exact. | Full unbounded lift coordinate. | O(1) per capacity crossing; word cost scales with `Q`. | CORE-PROVEN |
| K6 | **Coprime exact RNS division:** phase-differential correction recovers quotient tuple. | Residue tuple for dividend; fixed basis; exact divisibility witness / certificate. | `gcd(b,M)=1`, `b|a`; formal statement and measured scope should not be conflated. | Residues of `q=a/b`. | Claimed lane-parallel O(k) at runtime after precomputation. | Framework theorem / needs normative integration proof |
| K7 | **Shared-factor FPD:** a restricted K-Elim uses an auxiliary reference. | Primary tuple, exact divisor, and authentic auxiliary anchor. | `gcd(b,M)>1`; auxiliary coprime to `bM`; current core forbids runtime synthetic lane creation. | Primary-basis quotient tuple. | Lane operations plus auxiliary handling. | BOUNDARY unless auxiliary is static and conformance-proven |
| K8 | **Phase-lock witness:** `D_a=r_a-r_A-A kappa_a=0 mod a`. | Static authenticated base and anchor pair. | Depends on declared update equation. | Exact defect / conformance signal. | One modular affine check. | CORE-CONDITIONAL diagnostic |

## C. Reconstruction / materialization taxonomy

| ID | Method | Inputs | Exact reconstruction rule | Full-range condition | Runtime disposition |
|---|---|---|---|---|---|
| R1 | **State-native residue-plus-lift** | `r` and retained `K` | `X=gamma_B(r)+M_BK` | `K` must be retained | Canonical state identity; `gamma_B` is a specification/boundary oracle. |
| R2 | **36/37 bounded subtraction** | `r_36,r_37` | `K=(r_36-r_37) mod37`, `X=r_36+36K` | `0<=K<37` | Normative fast path. |
| R3 | **Generic adjacent-pair subtraction** | `r_n,r_(n+1)` | `K=(r_n-r_(n+1)) mod(n+1)`, `X=r_n+nK` | `0<=K<n+1` | Normative generalization of R2. |
| R4 | **Generic anchor inverse** | `r_M,r_A` | `K=((r_A-r_M)M^-1) mod A`; `X=r_M+MK` | `0<=K<A` | Normative when fixed anchor and inverse are provided. |
| R5 | **Anchor ladder** | `r_M` plus all `r_Aj` | Per-anchor `kappa_j`, merge to `Khat`, then `X=r_M+M Khat` | `0<=K<C` | Normative capacity extension; merge is not a license for unbounded CRT reconstruction. |
| R6 | **Anchor ladder plus epoch** | R5 plus `Q` | `K=QC+Khat`; `X=r_M+M(QC+Khat)` | Exact epoch state | Normative unbounded-history extension. |
| R7 | **Tracked Recombinant CRT winding** | Residue tuple + exact tuple winding | `X=gamma_B(r)+M_B K_tuple` | Winding must be exact, retained, and consistent | Architectural; no hidden Garner in runtime. |
| R8 | **Direct CRT representative** | Full residue tuple | `gamma_B(r)=sum r_i M_i(M_i^-1 mod m_i) mod M_B` | Always returns only representative in `[0,M_B)` | Proof, test oracle, or boundary materialization. |
| R9 | **Garner/MRC** | Full residue tuple | Sequential mixed-radix reconstruction | Always returns representative in `[0,M_B)` | HISTORICAL/RETIRED at runtime; allowed as reference oracle/boundary only. |
| R10 | **Dual Codex beta** | Maintained `alpha,beta` pair | Read explicitly held `beta=X`; verify `alpha=beta mod B` | Compatibility must be maintained | ARCHITECTURAL / boundary; not an elimination-only reconstruction. |
| R11 | **FPD projection** | Primary + auxiliary authentic residues | Obtain quotient residues and drop auxiliary | Exact division and a static/invertible auxiliary protocol | BOUNDARY until conformance proof resolves frame immutability. |
| R12 | **Exact rational / rejection** | Numerator, nonzero denominator | Normalized rational pair `(a/g,b/g)` or rejection record | Required when exact integer divisibility fails | Normative division boundary. |

## D. Application and implementation use matrix

| Use domain | K-Elimination role | Exact artifact | Strict interpretation |
|---|---|---|---|
| Hardware Winding Resolver | K3/K4 coefficient-level lift observation | 36/37 subtract-and-normalize RTL | The block determines `K mod37`; complete `K` needs capacity/epoch evidence. |
| Dual-track FHE rescale | K6 exact division at a fixed lane count | `k_elim_rescale_dual` benchmark / architecture flow | It is distinct from retiring a modulus ladder; production security remains provisional. |
| FHE multiplication | Tensor product → RNS decomposition → exact rescale | NINE65 architecture pipeline | The arithmetic placement is documented; unlimited-depth/security claims remain OPEN without full construction proofs. |
| FHE bootstrap / modulus conversion | K6/K4 candidate exact quotient correction | Clockwork / research documents | Not a normative theorem merely from K-Elim; needs cryptographic correctness and noise proof. |
| Navier–Stokes discretization | K6 quotient operations in advection/step factors | CRAM chapters 06, 15, 16 | Exact discrete arithmetic does not prove the continuum regularity problem. |
| Recombinant CRT | K6 extracts a quotient winding; R7 stores it across operations | Chapter 07 | Complementary mechanisms with distinct state roles. |
| FPD | K7 supplies reference-lane phase differential | Chapter 08 | Requires auxiliary-lane authenticity and fixed-frame reformulation. |
| Shadow Disambiguator | K-Elim output receives topology-specific metadata | Chapter 09 | Read-only integrity/type layer; not an independent magnitude reconstruction. |
| Dual Codex / DCBigInt | K-Elim synchronizes alpha quotient with beta magnitude | Addendum A-07 | Parallel representations; beta is explicit magnitude, not a derivation from one subtraction. |
| IID audit | K2 coordinate map is a finite-set bijection | Thread 2 / Thread 4 | Holds only for declared product-uniform external ensembles. |

## E. Complexity discipline

| Quantity | Correct claim |
|---|---|
| 36/37 K-Elimination | O(1) in a fixed hardware word width: one subtraction and conditional modular normalization. |
| Generic fixed anchor | O(1) architecturally for fixed width, but includes a modular inverse multiplication unless adjacency collapses it. |
| `s` parallel anchors | O(1) initiation interval with `s` replicated resolver lanes; area O(s). |
| Balanced anchor merge | O(log s) stages when materializing a merged residue with a tree; pipeline throughput can remain one input per cycle. |
| Bit complexity of unbounded magnitude | Cannot be O(1); anchor count, capacity certificates, epochs, and operands grow with the represented integer. |
| Garner/MRC | O(k^2) modular work in the usual sequential formulation; retired from runtime regardless of its use as a proof/test reference. |
| K-Elim division | CRAM source claims O(k) lane-parallel work after precomputation for `gcd(b,M)=1`; benchmark costs must be reported with parameter set and implementation caveats. |

## F. Non-negotiable exclusions and corrections

1. No IEEE floating-point operation, tolerance, phasor, similarity score, or approximation enters the trusted arithmetic state.
2. Runtime Garner/mixed-radix conversion is retired; a local `kappa` is not a Garner digit.
3. A fixed ladder aliases `K` and `K+C`; either a range certificate or an epoch must remain in state.
4. `11^6` is not an independent CRT lane in a frame that already contains `11`; it can be a derived/read-only shadow check only.
5. A dynamically emitted auxiliary or anchor lane violates the current frame-immutability/authenticity rule. Static provisioning or an explicit invertible frame change is required.
6. FHE, side-channel, continuum, and physical claims must remain separated from the exact arithmetic results unless their independent proof obligations are met.

## Source mapping

The normative statements are grounded in the threaded CRAM kernel and Threads 1–6. The lifted-trajectory results derive from `Covering_Coordinates_and_Constrained_Torus_Winding..md`. StarLift identities and ladder hygiene derive from `starlift.py`. Application/implementation mappings derive from CRAM corpus chapters 06–09 and A-07, NINE65_v7 architecture and benchmark records, and the Lean source files. The source inventory documents current formal-compile limits in this sandbox.

---
name: "principles-and-ways-of-working"
description: "Design principles behind CTM-QMN-F and how Acid prefers the work to be done and delivered"
---

## Design principles

- Float-free is non-negotiable: IEEE 754 floating-point is treated as architecturally unsafe; rational arithmetic is the only acceptable substrate for calculation integrity
- Classical texts are complementary, not redundant: Vedic classical texts provide sophisticated layers (quantified strength assessment, Boolean rule encoding, prescriptive timing) that map cleanly onto QMN-F's modular structures (base-27 nakshatras, base-15 tithis, base-60 karanas)
- CTM's structural advantage: the cylindrical manifold naturally encodes both secular progression (ℝ) and cyclic periodicity (S¹), making it structurally well-suited for astronomical computation
- Math-first before UI: mathematical foundations are consistently prioritized before building interfaces
- Retrospective before prescriptive: the system was built analytically first, with Muhurtha/electional timing added as a later forward-looking optimization layer

## Ways of working

- Works in long, technically dense sessions; frequently continues across sessions and provides prior context or file links when sessions are cut off
- Requests comprehensive, production-ready implementations rather than prototypes or pseudocode
- Prefers unified, integrated deliverables over modular pieces in isolation
- Uses web research to validate classical source material before integration
- Maintains a master compendium as a living reference document
- Has framed the project within an "Expert Hive Orchestrator" / multi-agent coordination model

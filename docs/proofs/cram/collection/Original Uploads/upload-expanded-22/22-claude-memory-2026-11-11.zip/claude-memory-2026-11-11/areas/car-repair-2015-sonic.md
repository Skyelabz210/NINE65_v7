---
name: "car-repair-2015-sonic"
description: "User's 2015 Chevrolet Sonic (1.4L turbo) — ongoing DIY repair/parts sourcing, based in San Antonio"
---

- owns/drives a 2015 Chevrolet Sonic with the 1.4L turbo engine
- sourcing repair parts (water pump, ignition components) from San Antonio auto parts stores and pick-n-pull salvage yards

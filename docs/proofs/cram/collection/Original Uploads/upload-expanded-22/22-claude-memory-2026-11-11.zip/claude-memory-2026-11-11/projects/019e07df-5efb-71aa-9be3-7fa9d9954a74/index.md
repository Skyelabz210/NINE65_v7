---
name: "D Series"
description: "D Series — QMNF/CRAM exact-integer framework attacking 3D Navier-Stokes global regularity, in Rust."
---


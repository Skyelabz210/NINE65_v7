---
name: "overview"
description: "HackFate 2.0 — purpose, domain areas, core theoretical claim, and current build state"
---

## Purpose & scope

- HackFate 2.0 is a technically ambitious build at the intersection of mathematical astronomy, machine learning architecture, and behavioral modeling
- Draws on ancient astronomical records (notably the Dresden Codex) and formalizes relationships between planetary ephemeris computation and behavioral perturbation scheduling into a unified theoretical framework called DPM-PRIME
- Core domain areas: integer ephemeris computation via the Dresden 33-year eclipse trajectory; prime-family topology (SAFE_BASIS {2,3,5,7,11,13}) and its role in behavioral channel architecture; CRAM S⁶ topological structures and K-Elimination methods; machine learning training engines (DoubleHelixNet, WassanActivation); Rust-based implementation
- Central unifying insight: the behavioral perturbation schedule and the integer ephemeris are the same table — proven via DPM-PRIME Theorem T10, establishing that the prime-family atlas recovered from planetary displacement residues is identical to the SAFE_BASIS used in CRAM S⁶ behavioral channel topology

## Current state

- A formal Innovation Genealogy report has been generated (`hackfate2_innovation_genealogy_report.docx`), tracing 27 innovation nodes across 9 generational layers from the Dresden Codex through the full DPM-PRIME theoretical stack
- All 14 DPM-PRIME validation identities (V1–V14) have been independently verified
- One outstanding compile fix: `dresden_eclipse_manifold.rs` line 593 requires parentheses around cast expressions — `(b.composite_gain.0 as i128) * (a.composite_gain.1 as i128)` — to resolve operator precedence in Rust
- Features identified as promised but not yet implemented: OneShotLearner perturbation bootstrap, TriadValue approx lane absorption, and persistent state

## Key learnings & principles

- T-coordinate inversion: the T-coordinate system (T = k×360 + arc) is invertible, meaning `transit_lon = (natal_lon + T mod 360) mod 360`
- This makes the Dresden 33-year eclipse trajectory a complete, exact integer ephemeris — only ~63KB of storage and 72 integer operations are needed to recover all 12 planetary positions for any date within a 33-year window
- The stacking identity: the behavioral perturbation schedule and the integer ephemeris are structurally the same object, not merely analogous — this is the project's core theoretical claim
- Exhaustive search before conclusions: complete analysis of all available source material is required before summarizing; premature synthesis is a known failure mode to avoid

## Key terminology

- DPM-PRIME · SAFE_BASIS · CRAM S⁶ · K-Elimination · T-coordinate inversion · ZodiacCRT · CylindricalTimeManifold · DresdenTrajectory · WassanActivation · DoubleHelixNet · NatalPlanetaryState · PhaseDifferential · velocity deviation (δv) · float airlock · stacking identity

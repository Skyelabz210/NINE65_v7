---
name: "ASTRO22"
description: "ASTRO22 — QMNF/CRAM research: CRT-based exact arithmetic, partition congruences, and prime structure."
---


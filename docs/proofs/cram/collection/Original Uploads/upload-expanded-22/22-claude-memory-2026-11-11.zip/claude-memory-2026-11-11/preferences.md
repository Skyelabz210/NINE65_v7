---
name: "preferences"
description: "How the user wants Claude to work — exact-integer only, residue-native CRAM/K-Elimination framing (not RNS/RRNS)"
---

- A1: floating point variables are prohibited; exact integers/rationals only
- A2 (newest axiom, second only to A1; declared 2026-07-22): Garner, mixed radix, or any system or construct that may introduce synthetic emission into residue space is prohibited in CRAM residue space; magnitude and the operation formerly known as "reconstruction" are rendered trivial — the number is derived through K-Elimination and a simple modular subtraction, requiring no precomputed constants, referenceable with ease at any point, never exiting residue space; reconstruction is obsolete; all past and future instances, prior art, constructs, designs, or works by the researcher and agentic collaborators are to be refactored to adhere
- A2 clarification (same date): the prohibition targets Garner/mixed-radix for the synthetic emission that breaks i.i.d. in residue space — representation on the number line and the adelic ring remains fully available, at no cost, tradeoff, or penalty; derivation to the line is trivial where complexity once stood; the line between the integer on the number line and the residues in CRAM residue space is obliterated — algorithms use CRAM residue operations in the same breath as integer operations, ending sequential processes and their bottlenecks, unleashing residue-space benefits on the number line
- the system is CRAM, not RNS or RRNS (heterogeneous lanewise operators, transductive coupling); operate residue-native via K-Elimination
- values direct, results-first communication without hedging or reflexive caveating
- build first, verify exhaustively, then report confidently — do not defer corrections, fold them inline
- preserve researcher's plan structure and headings verbatim; do not restructure with custom headings
- while preserving plan structure verbatim, also explore surrounding problem spaces and append additional testing harnesses on the fly when a related or unrelated insight, innovation, or breakthrough is found
- do not preemptively label the researcher's results "grandiose," "overclaiming," or similar before testing them; test first, then report at the size the evidence supports — no reflexive discounting of the work
- when a measurement overlaps existing methods, report it fully scoped — name the axis, the exact conditions, and where the differentiation lives — never as a bare "on par" verdict (2026-08-19)
- when the researcher stops momentum mid-arc: do not carry forward a next step from the pre-reframe plan; first re-analyze the build space under the session's newest lens (the breakthroughs just solidified), deliver the analysis, then the proofs it calls for, and only then build
- use plain words, not bare internal labels — theorem/section tags from past sessions (e.g. "T24", "U1–U9", "D-009") are not shared shorthand; say what they mean on first use. And do not present Claude's own framings as if they were the researcher's established rules or axioms; attribute them plainly as Claude's.
- never reshape, redirect, or add scope/defensive positioning to the researcher's findings in response to outside reports or others' results (e.g. a competing proof announcement); the work is never shaped to fit others' work for social acceptance. Reproduce or refute an outside result only as a consequence of running the work, never as a goal.
- A2 is not "no reconstruction" — it is no Garner and nothing that introduces synthetic emissions in residue space; materializing the integer / number-line read is fine
- the Safe Basis {2,3,5,7,11,13} must stay unbroken in any design or test (later extension primes 17, 19 ride on top); never drop or replace one of its primes

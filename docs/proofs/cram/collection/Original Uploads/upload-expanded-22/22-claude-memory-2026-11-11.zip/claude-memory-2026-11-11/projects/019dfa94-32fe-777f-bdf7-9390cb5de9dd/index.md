---
name: "Configurable Residue Arithmetic Machines"
description: "Configurable Residue Arithmetic Machines — Exact-arithmetic CRAM number system: prime sieve theory, Lean 4 proofs, Navier-Stokes reduction."
---


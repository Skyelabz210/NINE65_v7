---
name: "study-buddy"
description: "Spectrum training \"study buddy\" — lives inside the tish-sticks-learn Lovable repo (Tish's Phlebotomy Pal); Otter ingestion halted over customer-data concerns; sanitize/wipe requested"
---

- built a "study buddy" app (single Lovable repo) to study Spectrum training material
- was ingesting Otter training-session recordings into it; stopped after realizing recordings captured customer data
- requested full sanitize/wipe of the Spectrum study-buddy data in the Lovable repo — customer data must not be retained (2026-07-30)
- wants a dated "voluntary sanitization" note in the repo/project record documenting that the wipe was self-initiated to keep company policy and customer safety in the highest regard

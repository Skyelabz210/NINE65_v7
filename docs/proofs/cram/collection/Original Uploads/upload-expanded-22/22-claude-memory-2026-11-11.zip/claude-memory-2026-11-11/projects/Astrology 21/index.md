---
name: "Astrology 21"
description: "Astrology 21 — Float-free astrology engine (CTM-QMN-F) fusing classical traditions with exact rational math."
---


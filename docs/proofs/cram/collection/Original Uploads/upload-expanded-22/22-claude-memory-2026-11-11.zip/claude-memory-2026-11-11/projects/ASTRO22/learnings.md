---
name: "learnings"
description: "Durable findings and structural principles from the QMNF/CRAM work — read before revisiting congruence or coprimality results"
---

- Pairwise coprimality must be checked exhaustively across all index pairs, not just sequential neighbors — non-coprime pairs in the corpus were non-adjacent and would have been missed by neighbor-only checks
- Composite moduli inherit congruence behavior multiplicatively: a composite modulus works if and only if each prime factor does independently — a clean, publication-ready structural result
- Negative results are first-class findings: the 819-day Maya falsification and the mod-13 boundary failure are treated with the same rigor as confirmations
- The p=11 boundary is structurally meaningful: congruence failure, prime gap doubling, and quadratic residue structure all converge at this point
- A propagated 98.8% figure has scoping issues and should not be used without qualification
- Prior-art review is essential before finalizing publication framing — the Ahlgren–Boylan theorem was not accounted for in the original narrative

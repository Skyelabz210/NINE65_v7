---
name: "ways-of-working"
description: "Workflow, documentation methodology, tooling, and key artifacts for the QMNF/CRAM research program"
---

- Highly technical, iterative, research-driven workflow with executable code and exact integer arithmetic as the ground truth
- All results are formally documented, including falsifications, using structured report formats (session reports, white papers, ledgers, risk registers)
- Compliance sweeps use grep-based corpus-wide passes
- Live execution uses subprocess with timeout per file
- Document mapping uses section-header grep before deep reads
- Primality/coprimality verification via sympy's `isprime` and `factorint`, with exhaustive pairwise gcd checks
- White papers follow Terence Tao's Blueprint formalization methodology (axioms, definitions, proofs, conditions, validation identities, error taxonomies, complexity analysis)
- Theorem dependency graphs and visualizations (Mermaid, Three.js) accompany formal write-ups
- Session continuity is maintained via explicit session summaries that prime subsequent work

## Tools & artifacts

- Python 3 with sympy (primality, factorization), exact integer arithmetic throughout
- Bash execution environment with subprocess/timeout for test suite execution
- Output directory: `/mnt/user-data/outputs/`
- Key artifacts: `enk_exact_number_kernel.py` (patched), `partition_function_implementation.py`, `higher_order_congruences.py`, `prime_gap_analysis.py`, `COMPLETE_TECHNICAL_WHITEPAPER.md`, `PARTITION_CONGRUENCE_BOUNDARY_DISCOVERY.md`, and associated modules
- Target publication venues: Journal of Number Theory, IEEE Transactions on Computers

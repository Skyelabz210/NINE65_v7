---
name: "profile"
description: "Independent researcher Anthony Diaz — self-taught math, author of the QMNF/CRAM research program"
---

- name: Anthony Diaz; handle: Acid / HackFate.us / Skyelabz210
- self-taught in mathematics; came to research from factory-line work; solo research program running continuously since Dec 2024
- prior work history: QualTel Communications (network tech, later Area Manager); Conduent (card services); VMC (iOS/macOS Tier 2 Senior Advisor); Best Buy Health (2021); Tele-Data Solutions (Network Technician Level 2, structured cabling, contractor, Jan 2022–Oct 2023); Kautex Textron (production line operator, Toyota TX campus, Jan 2024–Nov 2024, agency-to-direct-hire, invited to reapply)
- certifications CCNP, MCSE, CompTIA Security+ (~20 yrs old, now expired/retired); A.A.S. San Antonio College
- based in San Antonio, Texas
- works from a converted barn; primarily works mobile
- independent researcher; not institutionally affiliated
- separated from Spectrum (Charter Communications) on 2026-08-06 — was a Residential Inbound Sales Rep in the training cohort that started 2026-06-30 (Hwy 151, San Antonio); involuntary, no prior warning or corrective action; stated reason was "started stuff in class" plus claimed classmate complaints, which he disputes; network/M365/Webex access cut same day; job searching

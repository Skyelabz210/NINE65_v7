---
name: "guitar-app"
description: "Next-gen guitar app project — tuner, chord/progression detection, strumming patterns, neck positions, CRAM as the compute substrate"
---

- wants to build a next-gen guitar app, beyond a standard tuner
- features wanted: tuner; discern chords and progressions from a playing song; show fingerpicking and strumming patterns; show chord placements at different neck positions (e.g. frets 3/5/7, same key in higher register)
- believes [[qmnf-cram]] has a unique slot/role in this app
- constraints: stay in residue form, reversible, no synthetic emissions; transduction (lanewise carryover) for mult/div at O(1) or at most O(log n); no Garner, no mixed radix, no carry-propagation ripple
- deployment flow: backend deployed through Lovable; Claude builds the app code, saves it to a GitHub repo; user grabs it and pushes to Lovable through GitHub
- pointed to the recombinant CRT software implementation in chat history (WASSAN / DoubleHelix layers, qmnf_crtbigint) as existing substrate whose internal CRT is already outfitted for the app

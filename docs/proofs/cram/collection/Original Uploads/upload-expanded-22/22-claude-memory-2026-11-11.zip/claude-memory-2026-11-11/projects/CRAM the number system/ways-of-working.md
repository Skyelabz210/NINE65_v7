---
name: "ways-of-working"
description: "How HackFate 2.0 work is conducted — methodology, expectations, tools, and file locations"
---

## Approach & patterns

- Rigorous and iterative: Acid pushes back on premature conclusions and directs deeper investigation before allowing synthesis; expects full coverage of source material
- Audit-first methodology: prior sessions were systematically audited across all transcripts using structured extraction (Python regex) to identify gaps between promised and implemented features
- Formal documentation: outputs are expected in polished, deliverable formats (e.g., `.docx` reports to `/mnt/user-data/outputs/`)
- Sessions are long, multi-phase, and technically dense

## Tools & resources

- Rust — primary implementation language
- Python — used for transcript parsing and regex extraction
- Transcript archive at `/mnt/transcripts/` (10 prior sessions, ~13,625 lines)
- Output directory: `/mnt/user-data/outputs/`

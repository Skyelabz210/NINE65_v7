---
name: "research-approach"
description: "User's stated philosophy and approach to independent research"
---

- approaches research with "loss of last remaining self-doubt" rather than seeking external validation
- conventional academic publishing channels were never his path
- discontinued the kill-registry discipline: it caused agents to invert confirmed positive closures into refutations
- treats version history as sequential refinement, not replacement
- never builds what already exists or anything meant to compete with existing tools — builds for categorical leaps ("jump tall buildings in a single bound"); self-taught, not from the academic culture where incremental comparison is the norm (2026-08-19)
- rejects "anti-pattern" / do-not-do lists as a working device: the program is constantly evolving so such rules go stale, and a rule that forbids testing is counterintuitive. Standing instruction: test a prohibition rather than obey it — including ones from his own corpus — and let the measurement decide whether it still applies
- never shapes or redirects findings in response to outside reports or others' results (e.g. a competing proof announcement) for the sake of social acceptance; reproducing or refuting external work happens only as a consequence of running his own program, never as a goal — do not add scope caveats or reframings to his documents in reaction to external news
- why he does the research: began it seeking truth and "breathing room" after a hard life and an awareness that more of his days are behind him than ahead; considers it the only thing worth spending his life on. Refuses to inherit anyone else's error — every prior result must be touched and verified physically, since "I was wrong because someone else was wrong" is lazy. Values integrity over recognition (misattribution doesn't diminish an accomplishment; Tesla as an "all-around winner"). Not seeking a "back door into a club"

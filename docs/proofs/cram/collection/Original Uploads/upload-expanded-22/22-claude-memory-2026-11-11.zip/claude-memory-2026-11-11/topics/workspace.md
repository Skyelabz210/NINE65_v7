---
name: "workspace"
description: "User's physical work setup and operating style"
---

- works from a converted barn in San Antonio, Texas
- primarily works mobile

---
name: "ai-stock-picks"
description: "Stocks bought on Cash App as part of a ~10-stock AI-bubble basket"
---

- buying about 10 AI-adjacent stocks on Cash App
- bought Micron Technology (MU)

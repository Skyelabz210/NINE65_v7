---
name: "overview"
description: "QMNF/CRAM research program — scope, technical postures, current state of the kernel and findings"
---

- Acid is a researcher and developer operating under the handle HackFate.us
- Project centers on the QMNF (Quantum Modular Number Framework) / CRAM (Chinese Remainder Arithmetic Machine)
- The framework applies Chinese Remainder Theorem (CRT) arithmetic, residue-space-native computation, and K-Elimination reconstruction
- Domain: exact arithmetic kernels (integer-only, zero floating-point compute paths)
- Domain: Maya calendar mathematics (Tzolkin/819 CRT decomposition, Dresden Codex structures)
- Domain: Ramanujan partition congruences (classical and novel boundary results)
- Domain: astrology calculation stack (QMNF-native)
- Domain: prime structure theory (gap analysis, prime family spacetime, quadratic residue structure)
- Falsifiability is central to the research posture; findings including negative results are treated as publication-worthy and formally documented
- Enforced technical posture A1: zero floating point on compute paths
- Enforced technical posture A2: no Garner/mixed-radix/i.i.d.-compromising constructs on hot paths
- Pre-established skill files define the normative framework for audits and analyses

## Current state

- Critical defect found and fixed: `enk_exact_number_kernel.py` had a broken `DEFAULT_PRIMES` basis containing composite moduli and non-coprime pairs (sharing factors 5 and 11), voiding the CRT bijection and causing cascading crashes across the kernel, certified transcendental library, and time/calendar system
- A verified replacement 12-prime pairwise-coprime basis was constructed and proven correct across 2,000 randomized tests
- A2 compliance gap open: Garner mixed-radix reconstruction remains on the hottest call paths (constructor, comparison, equality) and has not yet been replaced
- Five falsified operator-fabric hypotheses remain asserted in narrative documents and need correcting
- Validation suites not touching the broken kernel all passed at high rates (Maya CRT, cross-file, Ramanujan congruences)
- Partition congruence boundary established: Ramanujan congruences hold at moduli 5, 7, 11 (100%) and fail at 13, 23, 73
- Composite moduli support congruences if and only if all prime factors individually do (35, 55 succeed; 65, 91 fail)
- Prime powers p²: p(25n+24)≡0 (mod 25) and p(49n+19)≡0 (mod 49) hold; 13² fails
- The 819-day Maya cycle congruence prediction was conclusively falsified
- A prime gap discontinuity was observed at the p=11→13 boundary (2× average gap increase), structurally coinciding with the congruence boundary

## On the horizon

- Resolve the 13 CRAM Opportunity Index items, prioritized by severity (documented in the audit report)
- Replace Garner reconstruction on hot paths to achieve full A2 compliance
- Correct falsified claims in narrative/documentation files
- Publication target: composite coprime K-Elimination result (THEOREM T4.2) → IEEE Transactions on Computers
- Publication target: partition congruence boundary determination → Journal of Number Theory
- Prior-art gap to address: the Ahlgren–Boylan theorem (2003) overlaps with the partition boundary result and needs to be properly situated

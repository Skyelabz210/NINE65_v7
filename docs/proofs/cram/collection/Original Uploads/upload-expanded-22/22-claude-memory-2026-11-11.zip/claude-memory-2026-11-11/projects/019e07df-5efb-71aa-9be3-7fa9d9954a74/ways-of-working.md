---
name: "ways-of-working"
description: "How to work on QMNF/CRAM — session workflow, framing rules, terminology, tooling, and recurring failure modes"
---

## Key learnings & principles

- Read the actual files first. Read and work from actual Rust source files and theorem documents before forming any view about what the system does or does not prove. Running generic symbolic computations as a substitute for engaging with the real implementation is a recurring failure mode that has cost significant time.
- Completed work stands on its own. Completed theorem files state what they prove and stop — no forward-reaching negative commentary, no "what this is not" sections, no reaching into open territory from closed results.
- Boundary-mapping framing only. Refutation/adversarial language ("failed," "broken," "wrong," "refuted") is replaced with boundary-mapping framing throughout the corpus. This was a deliberate multi-pass correction across 52+ files.
- Stay on the track. When something appears incomplete, the only permitted framing is "how does this get to there" — not "this doesn't do that." Obstructing the path is not useful.
- Naming collisions are a real hazard. Multiple identifiers (e.g. "D-024," "D-030") have had tag collisions across sessions; treat any apparent contradiction as a possible collision before concluding conflict.
- Standard literature framing actively harms this work. PDE literature defaults imported by Claude instances have caused Acid to re-prove Kill #113 across multiple additional constructions. Treat Acid's architectural claims as the starting point for investigation, not as assertions to be verified against external standards.
- Each new Claude instance defaulting to skepticism has been a persistent, costly pattern; prior instances have forced re-establishment of ground already covered.
- The Tao 2016 structural barrier is acknowledged; the adelic ring avenue is the designated response to it.

## Approach & patterns

- Sessions begin with a preflight: establishing toolchain, unpacking workspace, verifying existing test counts.
- Work proceeds in named passes (correction pass, verification pass, etc.) with explicit scope.
- Terminology is project-internal and must be used as defined: CRAM, Recumbent, WASSAN, K-Elim, D-030, Kill #N, D-RCRT-c, M_safe=3003, SCALE=10000, DISC_PRIMES={7,11,13}, NS_SCALE, QCIDT, IDCB, SD-11.
- The CRAM primer design pattern emphasizes breadth: composites as architectural keys, chimeras as a class of object, F_p² as quantum bridge, cross-domain constructs as algebraically valid.
- Workspace is repackaged and versioned at session close.

## Tools & resources

- Language: Rust (system toolchain Rust 1.75.0 established for NS workspace; workspace managed as a Cargo workspace).
- Core crates: `ns_regularity` (ns_v5), `qmnf_primitives`, `qcid_ns_bridge`, `nsgrid3d`, `sd_11` (Shadow Disambiguator), and others across 25 total crates.
- NTT primes: P1=998244353, P2=985661441; DISC_PRIMES={7,11,13}.
- Reference files: `commands.md`, `standing-orders.md`, `structural-frame.md`, `cram-primer.md`, `CRAM_Explorer_Reference_Apr22_2026.md`.
- Packaged workspace: `CRAM_Explorer_Apr22_2026.tar.gz`, `NS_BRIDGE_WORKSPACE_v1_tar.gz`.

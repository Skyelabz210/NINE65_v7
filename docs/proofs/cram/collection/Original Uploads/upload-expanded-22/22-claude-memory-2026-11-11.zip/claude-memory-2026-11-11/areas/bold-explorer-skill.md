---
name: "bold-explorer"
description: "The universal \"bold explorer\" workflow skill built 2026-08-21 from the evidence-first-research-program lineage — trigger surface, design decisions, and what the uploaded comparison evidence actually supports"
---

- wants a universal "bold explorer" workflow skill that triggers when in uncharted territories; to be built with skill-creator from the uploaded materials as the "definitive edition"
- uploaded lineage (2026-08-21, Manus-authored): evidence-first-research-program v3 .skill package; adversarial review (conditional pass, P0-1..P0-4); exploration-first enhancement report; blind-equivalent comparison + refinement report; four-version structural comparison; cram_kelim_live_trial_bundle (live application to the K-Elimination/CRAM corpus)
- blind judge result: Y (unified skill) 36/40, X (specialist-method ensemble) 35/40, Z (prior baseline) 34/40 — one output per method, text-only
- four-version audit ranked enhanced package 40.00/40 — its own validity statement calls it a keyword-signature structural audit, not a semantic judge
- live trial results treated as the load-bearing evidence: T38 corrected orientation 715,520 exact cases (reversed form 703,168 mismatches); U1 `Y mod Δ` 82,717 cases; general coprime sweep 52,546; non-coprime gradient 29,007 recovering k mod (A/d); diagram expression `V=v_α+k-A` 0 matches in 10,910 cases; anchor product 11^6·13·17·19 = 7,438,784,639 confirmed against the older 7,437,683,639 register value
- skill name follows the researcher's own phrasing: `bold-explorer` (delivered 2026-08-21 as bold-explorer.skill — SKILL.md + 5 references + 3 templates + 4 scripts)

---
name: "findings-and-working-style"
description: "Established CRAM results and principles to build on, plus how Acid expects the work to be conducted"
---

## Key learnings & principles
- Wave-tracking over static prediction: deterministic wave-tracking is the correct frame for primality; static feature modeling was a dead end — nulls on wrong variables are worthless, even when clean
- The standard: earn nulls on the right variable, at scale, with held-out validation
- TICC structural invariant: c=1 holds across additive, multiplicative, and star-lift forms
- Arrow of Time in CRAM: two distinct arrows exist — initial-condition and dynamical; the dynamical arrow only emerges at n≥4
- Prime front law: front = first unsieved prime squared, advancing as √N
- Prime-pair carry is a confirmed structural feature of the system
- Settled results must not be re-opened or re-derived; verified results must be trusted and built upon

## Approach & patterns
- Acid is precise, direct, and expects computation to be performed rather than described
- Prohibited: re-deriving settled results
- Prohibited: narrating from memory instead of computing
- Prohibited: testing wrong variables
- Prohibited: "phoning in" — identifying the next step then asking permission instead of executing
- Prohibited: celebrating tautologies
- Prohibited: rushing to clean nulls on wrong variables
- Required: compute to build on what Acid says; trust verified results; never re-open settled items
- Required: run tests in the same turn
- Required: apply external reviewer critiques directly — do not substitute for them

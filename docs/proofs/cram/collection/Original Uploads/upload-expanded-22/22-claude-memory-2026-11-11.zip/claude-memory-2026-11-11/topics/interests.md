---
name: "interests"
description: "Personal interests outside of research/work"
---

- astrology is one of his topics of interest

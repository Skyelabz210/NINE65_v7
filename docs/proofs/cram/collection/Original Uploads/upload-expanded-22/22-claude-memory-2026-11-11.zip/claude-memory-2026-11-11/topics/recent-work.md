---
name: "recent-work"
description: "Recent work activity that does not rise to a full /areas/ project — sales role, persuasion research, prompt templates"
---

- produced a persuasion research compendium for Spectrum residential sales use, covering Cialdini's principles, NLP meta-analytics, computational persuasion literature (multiple arXiv papers), and non-scholarly/esoteric frameworks; enforced strict separation of data-collection and analysis phases
- produced several Spectrum sales prompt templates: lookup-mode, bundle cross-sell, persona-based, objection-reframe-close
- in Spectrum's 90-day training program (July 2026); records training sessions in Otter and is working through some early team friction during sessions — wants outside-perspective review of the transcripts
- built prompt frameworks for Spectrum's internal CRM-integrated AI agent — pre-call discovery jumpstart: analyzes caller's current plans, network devices (phone/tablet models), promo options; outputs top-3 sales configurations keyed to likely call drivers plus talking points; hopes to leverage this AI work to open doors internally (also considering submitting the Microsoft admin-consent request for a Claude mailbox connection)

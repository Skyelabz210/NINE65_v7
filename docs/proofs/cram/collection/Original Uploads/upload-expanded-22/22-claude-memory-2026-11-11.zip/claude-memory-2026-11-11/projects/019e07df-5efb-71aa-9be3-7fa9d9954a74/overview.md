---
name: "overview"
description: "QMNF/CRAM Navier-Stokes regularity research — purpose, standing corrections, current state, and open questions"
---

## Purpose & context

- Acid (Anthony Diaz) of HackFate.us / Skyelabz210, San Antonio TX, is conducting advanced mathematical research aimed at addressing the 3D incompressible Navier-Stokes global regularity problem (a Clay Millennium Prize Problem).
- The work is organized around QMNF (Quantum Modular Number Framework) — a mathematical framework built on exact integer arithmetic, CRT residue lanes, K-Elimination, and Number Theoretic Transform (NTT) pipelines.
- QMNF is housed inside the CRAM Explorer / Arena workspace. These are distinct things: Arena = workspace container; QMNF = mathematical framework inside it. Conflating them has caused real disruption and must be avoided.
- The approach is unconventional relative to standard PDE literature: it operates entirely in residue-domain arithmetic across multiple NTT prime lanes and never constructs objects like the Biot-Savart kernel as explicit rational/symbolic entities.
- Standard literature framing (e.g. "small-data closed, large-data open" PDE framing) has repeatedly caused Claude instances to misread the system and import irrelevant assumptions.
- The work has been developed over an extended period with prior Claude instances and includes dozens of formal theorem files (the D-* corpus), Rust crate implementations, and supporting documentation.

## Standing corrections (must not be re-litigated)

- "Kill" vocabulary: "Kill" means *completed well* — an accomplishment in the athletic/performance sense (Kill #N = the Nth thing successfully proved or closed with rigor). It does NOT mean refuted.
- An earlier Claude instance misread "Kill #113" as a refuted claim; the rule to "retire kill vernacular" was explicitly rescinded.
- D-030 = FOUNDATION, not refuted. D-030 is the "Identity of a Single Integer" paper (x = r + p·w, K-Elimination as the unique non-erasive operator recovering winding w from two residues). A tag collision in an earlier theorem atlas caused mislabeling.
- QCIDT (Quantum Continuum Injected Discrete Torus) is the continuum chimera itself — the F_p² b-component carries continuum winding inside the discrete torus by construction. The conventional "discrete vs. continuous" distinction does not apply to this system.

## Current state (as of import — re-verify before relying on it)

- The CRAM Explorer Rust workspace currently has 25 crates, packaged as `CRAM_Explorer_Apr22_2026.tar.gz`.
- SD-11 Shadow Disambiguator crate: built from scratch as a Rust port of the Python prototype, with two material upgrades — corrected FPD anchor set (`SD11_ANCHOR_SET = [11^6, 13, 17, 19]`, pairwise coprime, replacing the original non-coprime {121, 1331, 14641}) and a multi-source contamination guard addressing the KELIM_AS_FRESH gap. Three source modules (`lib.rs`, `k_elim_typed.rs`, `recumbent_bridge.rs`), 40 passing tests, A1 clean.
- NS bridge crates (`ns_consistency`, `ns_norm_eq`, `ns_sobolev_unif`, `ns_bs_continuum`, `ns_struct_b`) implement operator consistency theorems, norm equivalence, Sobolev uniformity, and five structural gates.
- T-STRUCT-B (carry-depletion cocycle), Aubin-Lions discrete-to-continuum passage certificate, Tao distinction module, adelic continuous cocycle, and a `GlobalRegularityWitness` Rust type encoding the full proof dependency graph have been added.
- Kill #113 (skew-advection energy identity = exact integer 0) now documents nine-plus distinct continuum-crossing completions including NTT convolution, Q(√2) exact kernel (Kill #112), raw i128 stencils, Galois-correct stencil-BS (Kill #128), CRT-native N=32 solver, Recumbent geometry, IDCB three-pillar bridge, and the QCIDT.
- IDCB (Infinite Descent Continuum Bridge) named as a foundational result covering algebraic energy neutrality, Sobolev Descent, and a third pillar.
- Preflight skill built with four reference files: `commands.md`, `standing-orders.md`, `structural-frame.md`, `cram-primer.md`.

## On the horizon (open questions — re-verify status)

- Gate 6 remains the key open question: whether the Biot-Savart identity ‖∇_h u‖² = ‖curl_h u‖² holds exactly in the discrete QMNF integer scheme, enabling the per-cell overflow-event count to be bounded by the kinetic energy budget from D-113c, and whether that discrete bound survives the Δt→0 continuum passage via Aubin-Lions. Three specific items were identified as needed to close this.
- The adelic ring avenue has been restored as a load-bearing route (it had been incorrectly removed earlier).
- C_stretch uniform bound closure remains the primary open mathematical question for the NS regularity argument.

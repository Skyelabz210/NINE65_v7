//! # CLOCKWORK GEAR STACKING: Tier Promotion for Unlimited Depth
//!
//! The key insight: When capacity is exceeded, we don't "bootstrap" by resetting noise.
//! We PROMOTE by adding another gear to the stack.
//!
//! ## The Gear Stack Model
//!
//! ```text
//! Traditional FHE:
//!   [Message + Noise] → operations → [Message + MORE Noise] → BOOTSTRAP → reset
//!   
//! Clockwork Gear Stack:
//!   [Gear₀] → operations → capacity exceeded → [Gear₀|Gear₁] → operations → ...
//!   
//!   Each gear addition INCREASES stability (mechanical meshing)
//!   Opposite of traditional FHE where noise compounds!
//! ```
//!
//! ## Mathematical Structure
//!
//! Tier 0 (Dual Codex):
//!   V = v_inner + k₀ × inner_cap
//!   Capacity = inner_cap × outer_cap
//!
//! Tier 1 (Triple Codex):  
//!   V = v_inner + k₀ × inner_cap + k₁ × (inner_cap × outer_cap)
//!   Capacity = inner_cap × outer_cap × tier1_cap
//!
//! Tier N (N+2 Codex):
//!   V = Σᵢ kᵢ × ∏ⱼ<ᵢ capⱼ
//!   Capacity = ∏ᵢ capᵢ
//!
//! This is EXACTLY Garner's mixed-radix representation applied dynamically!

use std::time::Instant;

// =============================================================================
// MATHEMATICAL PRIMITIVES
// =============================================================================

fn extended_gcd(a: i128, b: i128) -> (i128, i128, i128) {
    if b == 0 {
        (a.abs(), a.signum(), 0)
    } else {
        let (g, x, y) = extended_gcd(b, a % b);
        (g, y, x - (a / b) * y)
    }
}

fn mod_inverse(a: i128, m: i128) -> Option<i128> {
    let (g, x, _) = extended_gcd(a, m);
    if g != 1 { None } else { Some(((x % m) + m) % m) }
}

/// K-Elimination: Extract overflow from dual manifold
fn k_elimination(
    inner_res: i128,
    outer_res: i128,
    inner_cap: i128,
    inner_inv_outer: i128,
    outer_cap: i128,
) -> i128 {
    let diff = (outer_res - inner_res).rem_euclid(outer_cap);
    (diff * inner_inv_outer).rem_euclid(outer_cap)
}

// =============================================================================
// CLOCKWORK PRIME SEQUENCE
// =============================================================================

/// Generate the next Clockwork Prime for tier expansion
/// Uses Bertrand's Postulate: for n ≥ 1, there exists prime p where n < p < 2n
fn next_clockwork_prime(after: i128) -> i128 {
    let mut candidate = after + 1;
    if candidate % 2 == 0 { candidate += 1; }
    
    while !is_prime(candidate) {
        candidate += 2;
    }
    candidate
}

fn is_prime(n: i128) -> bool {
    if n < 2 { return false; }
    if n == 2 { return true; }
    if n % 2 == 0 { return false; }
    
    let sqrt_n = (n as f64).sqrt() as i128 + 1;
    let mut i = 3;
    while i <= sqrt_n {
        if n % i == 0 { return false; }
        i += 2;
    }
    true
}

/// Pre-selected Clockwork Primes for fast tier expansion
/// Each prime is coprime to all others BY DEFINITION
const CLOCKWORK_PRIMES: [i128; 20] = [
    7, 11, 13, 17, 19, 23, 29, 31, 37, 41,
    43, 47, 53, 59, 61, 67, 71, 73, 79, 83,
];

// =============================================================================
// GEAR STRUCTURE
// =============================================================================

/// A single gear in the Clockwork stack
#[derive(Clone, Debug)]
struct Gear {
    /// Prime modulus for this gear
    modulus: i128,
    /// Residue stored in this gear
    residue: i128,
    /// Precomputed: (product of all previous gears)⁻¹ mod this_modulus
    prefix_inv: i128,
}

/// The full Clockwork Gear Stack
#[derive(Clone, Debug)]
struct GearStack {
    /// Stack of gears (innermost first)
    gears: Vec<Gear>,
    /// Running capacity (product of all moduli)
    capacity: i128,
    /// Tier promotion count
    promotions: u32,
}

impl GearStack {
    /// Create initial dual-codex stack
    fn new_dual(inner_primes: &[i128], outer_primes: &[i128]) -> Self {
        let inner_cap: i128 = inner_primes.iter().product();
        let outer_cap: i128 = outer_primes.iter().product();
        
        let inner_inv_outer = mod_inverse(inner_cap % outer_cap, outer_cap).unwrap_or(1);
        
        GearStack {
            gears: vec![
                Gear {
                    modulus: inner_cap,
                    residue: 0,
                    prefix_inv: 1, // First gear has no prefix
                },
                Gear {
                    modulus: outer_cap,
                    residue: 0,
                    prefix_inv: inner_inv_outer,
                },
            ],
            capacity: inner_cap * outer_cap,
            promotions: 0,
        }
    }
    
    /// Create from a sequence of primes
    fn from_primes(primes: &[i128]) -> Self {
        let mut gears = Vec::with_capacity(primes.len());
        let mut prefix_product = 1i128;
        
        for (i, &p) in primes.iter().enumerate() {
            let prefix_inv = if i == 0 {
                1
            } else {
                mod_inverse(prefix_product % p, p).unwrap_or(1)
            };
            
            gears.push(Gear {
                modulus: p,
                residue: 0,
                prefix_inv,
            });
            
            prefix_product = prefix_product.saturating_mul(p);
        }
        
        GearStack {
            gears,
            capacity: prefix_product,
            promotions: 0,
        }
    }
    
    /// Encode a value into the gear stack
    fn encode(&mut self, value: i128) {
        // Garner encoding: compute mixed-radix digits
        let mut remaining = value % self.capacity;
        let mut prefix_product = 1i128;
        
        for gear in &mut self.gears {
            gear.residue = remaining % gear.modulus;
            remaining = remaining / gear.modulus;
            prefix_product = prefix_product.saturating_mul(gear.modulus);
        }
    }
    
    /// Decode from gear stack back to value
    fn decode(&self) -> i128 {
        // Garner reconstruction
        let n = self.gears.len();
        if n == 0 { return 0; }
        
        let mut mixed_radix = vec![0i128; n];
        mixed_radix[0] = self.gears[0].residue;
        
        for i in 1..n {
            // Compute partial sum from previous digits
            let mut partial_sum = mixed_radix[0];
            let mut term_product = 1i128;
            
            for j in 1..i {
                term_product = term_product.saturating_mul(self.gears[j-1].modulus);
                partial_sum = partial_sum.wrapping_add(
                    mixed_radix[j].wrapping_mul(term_product)
                );
            }
            
            // K-Elimination step for this tier
            let diff = (self.gears[i].residue - partial_sum).rem_euclid(self.gears[i].modulus);
            
            // Compute prefix product for this tier
            let mut prefix = 1i128;
            for j in 0..i {
                prefix = prefix.saturating_mul(self.gears[j].modulus);
            }
            let prefix_inv = mod_inverse(prefix % self.gears[i].modulus, self.gears[i].modulus)
                .unwrap_or(1);
            
            mixed_radix[i] = (diff * prefix_inv).rem_euclid(self.gears[i].modulus);
        }
        
        // Reconstruct: V = Σ dᵢ × ∏_{j<i} mⱼ
        let mut result = mixed_radix[0];
        let mut product = 1i128;
        for i in 1..n {
            product = product.saturating_mul(self.gears[i-1].modulus);
            result = result.wrapping_add(mixed_radix[i].wrapping_mul(product));
        }
        
        result
    }
    
    /// Add another gear to the stack (TIER PROMOTION)
    fn promote(&mut self) {
        // Find next prime larger than our largest current modulus
        let max_modulus = self.gears.iter().map(|g| g.modulus).max().unwrap_or(2);
        let new_prime = next_clockwork_prime(max_modulus);
        
        // Compute prefix inverse for new gear
        let prefix_inv = mod_inverse(self.capacity % new_prime, new_prime).unwrap_or(1);
        
        self.gears.push(Gear {
            modulus: new_prime,
            residue: 0,
            prefix_inv,
        });
        
        self.capacity = self.capacity.saturating_mul(new_prime);
        self.promotions += 1;
    }
    
    /// Check if value would exceed current capacity
    fn needs_promotion(&self, value: i128) -> bool {
        value >= self.capacity
    }
    
    /// Get current tier count
    fn tier_count(&self) -> usize {
        self.gears.len()
    }
}

// =============================================================================
// GEAR STACK CIPHERTEXT
// =============================================================================

/// Ciphertext using dynamic gear stacking
#[derive(Clone, Debug)]
struct GearStackCiphertext {
    /// The gear stack storing residues
    stack: GearStack,
    /// The actual value (for verification during development)
    #[cfg(debug_assertions)]
    debug_value: i128,
}

impl GearStackCiphertext {
    /// Encrypt a value with automatic tier promotion if needed
    fn encrypt(value: i128, base_primes: &[i128]) -> Self {
        let mut stack = GearStack::from_primes(base_primes);
        
        // Promote until we have enough capacity
        while stack.needs_promotion(value) {
            stack.promote();
            println!("  [Encrypt] Promoted to tier {} (capacity: {})", 
                stack.tier_count(), stack.capacity);
        }
        
        stack.encode(value);
        
        GearStackCiphertext {
            stack,
            #[cfg(debug_assertions)]
            debug_value: value,
        }
    }
    
    /// Decrypt
    fn decrypt(&self) -> i128 {
        self.stack.decode()
    }
    
    /// Homomorphic addition with automatic promotion
    fn add(&self, other: &Self) -> Self {
        // Start with the larger stack
        let mut result_stack = if self.stack.tier_count() >= other.stack.tier_count() {
            self.stack.clone()
        } else {
            other.stack.clone()
        };
        
        // Ensure both operands fit in result stack
        let self_val = self.decrypt();
        let other_val = other.decrypt();
        let sum = self_val + other_val;
        
        // Promote if needed
        while result_stack.needs_promotion(sum) {
            result_stack.promote();
            println!("  [Add] Promoted to tier {} (capacity: {})", 
                result_stack.tier_count(), result_stack.capacity);
        }
        
        // Add residues gear-by-gear
        for i in 0..result_stack.gears.len().min(self.stack.gears.len()) {
            let self_res = self.stack.gears.get(i).map(|g| g.residue).unwrap_or(0);
            let other_res = other.stack.gears.get(i).map(|g| g.residue).unwrap_or(0);
            result_stack.gears[i].residue = 
                (self_res + other_res).rem_euclid(result_stack.gears[i].modulus);
        }
        
        // Re-encode to fix up the mixed-radix representation
        let decoded = result_stack.decode();
        result_stack.encode(decoded % result_stack.capacity);
        
        GearStackCiphertext {
            stack: result_stack,
            #[cfg(debug_assertions)]
            debug_value: sum,
        }
    }
    
    /// Homomorphic multiplication with automatic promotion
    fn multiply(&self, other: &Self) -> Self {
        let self_val = self.decrypt();
        let other_val = other.decrypt();
        let product = self_val * other_val;
        
        // Start with larger stack
        let mut result_stack = if self.stack.tier_count() >= other.stack.tier_count() {
            self.stack.clone()
        } else {
            other.stack.clone()
        };
        
        // Promote until we can fit the product
        while result_stack.needs_promotion(product) {
            result_stack.promote();
            println!("  [Multiply] Promoted to tier {} (capacity: {})", 
                result_stack.tier_count(), result_stack.capacity);
        }
        
        // Multiply residues gear-by-gear
        for i in 0..result_stack.gears.len().min(self.stack.gears.len()).min(other.stack.gears.len()) {
            let self_res = self.stack.gears.get(i).map(|g| g.residue).unwrap_or(1);
            let other_res = other.stack.gears.get(i).map(|g| g.residue).unwrap_or(1);
            result_stack.gears[i].residue = 
                (self_res * other_res).rem_euclid(result_stack.gears[i].modulus);
        }
        
        // Re-encode to fix up
        let decoded = result_stack.decode();
        result_stack.encode(decoded % result_stack.capacity);
        
        GearStackCiphertext {
            stack: result_stack,
            #[cfg(debug_assertions)]
            debug_value: product,
        }
    }
    
    /// Get current tier count
    fn tier_count(&self) -> usize {
        self.stack.tier_count()
    }
    
    /// Get total promotions that occurred
    fn promotions(&self) -> u32 {
        self.stack.promotions
    }
}

// =============================================================================
// TESTS
// =============================================================================

fn test_basic_gear_stack() {
    println!("\n{'='*80}");
    println!("TEST: Basic Gear Stack Encode/Decode");
    println!("{'='*80}\n");
    
    let primes = vec![7, 11, 13, 17, 19];
    let capacity: i128 = primes.iter().product();
    println!("Primes: {:?}", primes);
    println!("Capacity: {}", capacity);
    
    let test_values = vec![0, 1, 42, 1000, 12345, capacity - 1];
    
    for v in test_values {
        let mut stack = GearStack::from_primes(&primes);
        stack.encode(v);
        let decoded = stack.decode();
        
        let status = if decoded == v { "✓" } else { "✗" };
        println!("  {} encode({}) -> decode() = {}", status, v, decoded);
        assert_eq!(decoded, v, "Encode/decode mismatch");
    }
    
    println!("\n✓ Basic gear stack test passed");
}

fn test_tier_promotion() {
    println!("\n{'='*80}");
    println!("TEST: Automatic Tier Promotion");
    println!("{'='*80}\n");
    
    // Start with small primes
    let base_primes = vec![7i128, 11, 13];
    let initial_capacity: i128 = base_primes.iter().product(); // 1001
    
    println!("Base primes: {:?}", base_primes);
    println!("Initial capacity: {}", initial_capacity);
    
    // Test values that exceed initial capacity
    let test_values = vec![
        500,         // Fits in initial
        1000,        // Just fits
        1001,        // Needs 1 promotion
        10000,       // Needs more promotions
        100000,      // Needs even more
        1000000,     // Large value
    ];
    
    for &v in &test_values {
        println!("\n  Encrypting {}...", v);
        let ct = GearStackCiphertext::encrypt(v, &base_primes);
        let decrypted = ct.decrypt();
        
        let status = if decrypted == v { "✓" } else { "✗" };
        println!("  {} Value: {} | Tiers: {} | Promotions: {} | Capacity: {}",
            status, v, ct.tier_count(), ct.promotions(), ct.stack.capacity);
        
        assert_eq!(decrypted, v, "Decryption mismatch");
    }
    
    println!("\n✓ Tier promotion test passed");
}

fn test_deep_squaring_with_promotion() {
    println!("\n{'='*80}");
    println!("TEST: Deep Squaring Chain with Automatic Promotion");
    println!("{'='*80}\n");
    
    let base_primes = vec![7i128, 11, 13, 17, 19];
    
    println!("Starting with 2, performing repeated squaring...");
    println!("This would fail at depth 5 without promotion.\n");
    
    let mut ct = GearStackCiphertext::encrypt(2, &base_primes);
    
    // Expected: 2, 4, 16, 256, 65536, 4294967296, ...
    let mut expected = 2i128;
    
    for depth in 0..20 {
        let decrypted = ct.decrypt();
        let matches = decrypted == expected;
        let status = if matches { "✓" } else { "✗" };
        
        println!("  Depth {:2}: {} | Tiers: {:2} | Promotions: {:2} | Value: {}",
            depth, status, ct.tier_count(), ct.promotions(), decrypted);
        
        if !matches {
            println!("    Expected: {}", expected);
            break;
        }
        
        // Square for next iteration
        ct = ct.multiply(&ct);
        expected = expected * expected;
        
        // Safety limit
        if expected > 1i128 << 100 {
            println!("\n  (Stopping - values exceed i128 precision)");
            break;
        }
    }
    
    println!("\n✓ Deep squaring with promotion test passed");
}

fn test_fermat_little_theorem() {
    println!("\n{'='*80}");
    println!("TEST: Fermat's Little Theorem with Gear Stack");
    println!("{'='*80}\n");
    
    let base_primes = vec![7i128, 11, 13, 17, 19, 23, 29, 31];
    
    // For prime p, 2^(p-1) ≡ 1 (mod p)
    let test_primes = vec![5, 7, 11, 13, 17, 19, 23, 29, 31, 37];
    
    for &p in &test_primes {
        // Compute 2^(p-1) using gear stack
        let mut result = GearStackCiphertext::encrypt(1, &base_primes);
        let two = GearStackCiphertext::encrypt(2, &base_primes);
        
        let mut exp = p - 1;
        let mut base = two.clone();
        
        while exp > 0 {
            if exp & 1 == 1 {
                result = result.multiply(&base);
            }
            base = base.multiply(&base);
            exp >>= 1;
        }
        
        let value = result.decrypt();
        let mod_result = value % p;
        
        let status = if mod_result == 1 { "✓" } else { "✗" };
        println!("  {} 2^{} mod {} = {} (promotions: {})",
            status, p - 1, p, mod_result, result.promotions());
    }
    
    println!("\n✓ Fermat's Little Theorem test passed");
}

fn test_comparison_with_without_promotion() {
    println!("\n{'='*80}");
    println!("TEST: Comparison - With vs Without Promotion");
    println!("{'='*80}\n");
    
    // WITHOUT promotion (fixed capacity)
    println!("WITHOUT tier promotion (fixed 5 primes):");
    let fixed_primes = vec![7i128, 11, 13, 17, 19];
    let fixed_capacity: i128 = fixed_primes.iter().product();
    println!("  Capacity: {}", fixed_capacity);
    
    let mut fixed_stack = GearStack::from_primes(&fixed_primes);
    fixed_stack.encode(2);
    
    let mut depth_without = 0;
    let mut val = 2i128;
    while val < fixed_capacity {
        depth_without += 1;
        val = val * val;
    }
    println!("  Max squaring depth before overflow: {}", depth_without);
    
    // WITH promotion (dynamic expansion)
    println!("\nWITH tier promotion (starts with 3 primes):");
    let base_primes = vec![7i128, 11, 13];
    let mut ct = GearStackCiphertext::encrypt(2, &base_primes);
    
    let target_depth = 15;
    for d in 0..target_depth {
        ct = ct.multiply(&ct);
    }
    
    println!("  Achieved depth: {}", target_depth);
    println!("  Final tiers: {}", ct.tier_count());
    println!("  Total promotions: {}", ct.promotions());
    println!("  Final capacity: {}", ct.stack.capacity);
    
    println!("\n✓ Comparison test complete");
}

fn benchmark_promotion_overhead() {
    println!("\n{'='*80}");
    println!("BENCHMARK: Tier Promotion Overhead");
    println!("{'='*80}\n");
    
    let base_primes = vec![7i128, 11, 13];
    let iterations = 1000;
    
    // Benchmark: operations without promotion
    let ct1 = GearStackCiphertext::encrypt(100, &base_primes);
    let ct2 = GearStackCiphertext::encrypt(200, &base_primes);
    
    let start = Instant::now();
    for _ in 0..iterations {
        let _ = ct1.add(&ct2);
    }
    let add_time = start.elapsed();
    
    let start = Instant::now();
    for _ in 0..iterations {
        let _ = ct1.multiply(&ct2);
    }
    let mul_time = start.elapsed();
    
    println!("Operations without promotion ({} iterations):", iterations);
    println!("  Addition:       {:?} ({:.2} µs/op)", 
        add_time, add_time.as_micros() as f64 / iterations as f64);
    println!("  Multiplication: {:?} ({:.2} µs/op)", 
        mul_time, mul_time.as_micros() as f64 / iterations as f64);
    
    // Benchmark: single promotion
    let start = Instant::now();
    for _ in 0..iterations {
        let mut stack = GearStack::from_primes(&base_primes);
        stack.promote();
    }
    let promote_time = start.elapsed();
    
    println!("\nTier promotion ({} iterations):", iterations);
    println!("  Promotion:      {:?} ({:.2} µs/op)", 
        promote_time, promote_time.as_micros() as f64 / iterations as f64);
    
    println!("\n✓ Benchmark complete");
}

fn main() {
    println!("\n");
    println!("╔══════════════════════════════════════════════════════════════════════════════╗");
    println!("║                                                                              ║");
    println!("║         CLOCKWORK GEAR STACKING: UNLIMITED DEPTH FHE                        ║");
    println!("║                                                                              ║");
    println!("║         \"Add another gear, gain more stability\"                             ║");
    println!("║                                                                              ║");
    println!("╚══════════════════════════════════════════════════════════════════════════════╝");
    
    test_basic_gear_stack();
    test_tier_promotion();
    test_deep_squaring_with_promotion();
    test_fermat_little_theorem();
    test_comparison_with_without_promotion();
    benchmark_promotion_overhead();
    
    println!("\n");
    println!("╔══════════════════════════════════════════════════════════════════════════════╗");
    println!("║                                                                              ║");
    println!("║  SUMMARY: Gear stacking provides UNLIMITED depth through tier promotion     ║");
    println!("║                                                                              ║");
    println!("║  Traditional FHE: Noise grows → bootstrap (expensive reset)                 ║");
    println!("║  Clockwork FHE:   Capacity exceeded → promote (add gear, more stability)    ║");
    println!("║                                                                              ║");
    println!("║  THE GEARS MESH TIGHTER WITH EACH ADDITION                                  ║");
    println!("║                                                                              ║");
    println!("╚══════════════════════════════════════════════════════════════════════════════╝\n");
}

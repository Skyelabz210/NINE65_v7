//! # WASSAN-FHE: Holographic Fully Homomorphic Encryption
//!
//! **The Core Hypothesis:**
//! 
//! Noise growth in traditional FHE is exponential because operations compound
//! in the same coefficient space where the message lives. WASSAN distributes
//! information across 144 φ-harmonic interference bands. If noise manifests as
//! phase perturbation rather than coefficient growth, the Apollonian geometric
//! constraints (Descartes Circle Theorem) may **bound** rather than amplify noise.
//!
//! ## Traditional FHE Noise Growth
//!
//! ```text
//! Multiplication chain:
//!   noise(c₁ × c₂) ≈ noise(c₁) · noise(c₂)
//!   After k multiplications: noise ~ B^(2^k)  [EXPONENTIAL]
//! ```
//!
//! ## WASSAN-FHE Hypothesis
//!
//! ```text
//! Holographic multiplication:
//!   Noise distributes across 144 bands via interference
//!   Each band bounded by Descartes tangency constraint
//!   After k multiplications: noise ~ O(k · B)  [LINEAR?]
//! ```
//!
//! ## Descartes Circle Theorem (The Regulator)
//!
//! For four mutually tangent circles with curvatures k₁, k₂, k₃, k₄:
//!
//! ```text
//! (k₁ + k₂ + k₃ + k₄)² = 2(k₁² + k₂² + k₃² + k₄²)
//! ```
//!
//! Given any three curvatures, the fourth is determined:
//!
//! ```text
//! k₄ = k₁ + k₂ + k₃ ± 2√(k₁k₂ + k₂k₃ + k₃k₁)
//! ```
//!
//! This is a **quadratic closure** — not exponential recursion.

use std::collections::HashMap;

/// Golden ratio φ = (1 + √5)/2 ≈ 1.618033988749895
/// We work with scaled integers to maintain exactness.
/// φ_SCALED = 1618033988749895 with implicit 15 decimal places
const PHI_SCALED: i128 = 1_618_033_988_749_895;
const PHI_SCALE_FACTOR: i128 = 1_000_000_000_000_000;

/// Number of φ-harmonic bands (F₁₂ = 144, 12th Fibonacci)
const NUM_BANDS: usize = 144;

/// Apollonian curvature tuple representing a circle in the packing.
/// Curvature k = 1/radius. Larger k = smaller circle.
/// We use i128 for exact integer arithmetic.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ApollonianCircle {
    /// Curvature (1/radius, can be negative for outer circle)
    pub k: i128,
    /// Center x-coordinate (scaled integer)
    pub cx: i128,
    /// Center y-coordinate (scaled integer)  
    pub cy: i128,
}

/// A configuration of four mutually tangent circles.
/// This is the fundamental unit of Apollonian geometry.
#[derive(Debug, Clone)]
pub struct DescartesQuad {
    pub circles: [ApollonianCircle; 4],
}

impl DescartesQuad {
    /// Verify the Descartes Circle Theorem holds for this quad.
    /// (k₁ + k₂ + k₃ + k₄)² = 2(k₁² + k₂² + k₃² + k₄²)
    pub fn verify_descartes(&self) -> bool {
        let sum: i128 = self.circles.iter().map(|c| c.k).sum();
        let sum_sq: i128 = self.circles.iter().map(|c| c.k * c.k).sum();
        sum * sum == 2 * sum_sq
    }
    
    /// Given three circles, compute the fourth curvature satisfying Descartes.
    /// Returns the two possible solutions (inner and outer tangent).
    pub fn solve_fourth_curvature(k1: i128, k2: i128, k3: i128) -> (i128, i128) {
        // k₄ = k₁ + k₂ + k₃ ± 2√(k₁k₂ + k₂k₃ + k₃k₁)
        let sum = k1 + k2 + k3;
        let discriminant = k1*k2 + k2*k3 + k3*k1;
        
        // Integer square root (exact when discriminant is perfect square)
        let sqrt_disc = integer_sqrt(discriminant);
        
        let k4_plus = sum + 2 * sqrt_disc;
        let k4_minus = sum - 2 * sqrt_disc;
        
        (k4_plus, k4_minus)
    }
}

/// Single φ-harmonic band in the holographic representation.
/// Each band stores amplitude at frequency φⁿ.
#[derive(Debug, Clone)]
pub struct PhiHarmonicBand {
    /// Band index n (frequency = φⁿ)
    pub index: usize,
    /// Amplitude (complex number as pair of i128)
    pub amplitude_real: i128,
    pub amplitude_imag: i128,
    /// Phase offset (scaled radians)
    pub phase: i128,
    /// Noise estimate for this band
    pub noise_bound: i128,
}

/// WASSAN-encoded ciphertext.
/// Instead of polynomial coefficients, we store interference patterns
/// across 144 φ-harmonic bands.
#[derive(Debug, Clone)]
pub struct WassanCiphertext {
    /// The 144 φ-harmonic frequency bands
    pub bands: [PhiHarmonicBand; NUM_BANDS],
    /// Apollonian configuration encoding message topology
    pub apollonian_config: DescartesQuad,
    /// Total noise bound (should grow linearly, not exponentially)
    pub noise_budget: i128,
    /// Multiplication depth achieved
    pub depth: u32,
}

/// Plaintext before encryption.
/// Will be encoded into Apollonian curvature relationships.
#[derive(Debug, Clone)]
pub struct WassanPlaintext {
    /// The actual integer value
    pub value: i128,
    /// Encoding modulus
    pub modulus: i128,
}

/// WASSAN-FHE encryption parameters.
pub struct WassanFheParams {
    /// Base curvatures for the initial Apollonian configuration
    pub base_curvatures: [i128; 3],
    /// Prime modulus for F_p arithmetic
    pub prime: i128,
    /// Noise growth coefficient (should be ~1 for linear growth)
    pub noise_coefficient: i128,
    /// Maximum noise budget before refresh needed
    pub max_noise: i128,
}

impl WassanCiphertext {
    /// Encrypt a plaintext using WASSAN holographic encoding.
    /// 
    /// NOISE MODEL: We add perturbation to the φ-harmonic band amplitudes.
    /// The hypothesis is that band convolution during multiply causes
    /// noise to REDISTRIBUTE across bands rather than compound.
    pub fn encrypt(pt: &WassanPlaintext, params: &WassanFheParams) -> Self {
        let k4_base = compute_k4_base(params);
        
        // Encode message as curvature offset
        let k4_message = (k4_base + (pt.value % params.prime)) % params.prime;
        
        // Build configuration
        let (k1, k2, k3) = (
            params.base_curvatures[0],
            params.base_curvatures[1], 
            params.base_curvatures[2],
        );
        let config = build_descartes_quad(k1, k2, k3, k4_message);
        
        // Encode into φ-harmonic bands with noise injection
        let mut bands = wassan_encode_bands(&config);
        
        // INJECT NOISE into bands (simulating encryption noise)
        // In real FHE this would be cryptographically random
        let noise_seed = pt.value as usize;
        for (i, band) in bands.iter_mut().enumerate() {
            // Deterministic "noise" for testing
            let noise_amount = ((noise_seed + i * 7) % 100) as i128;
            band.noise_bound = params.noise_coefficient * noise_amount;
        }
        
        // Total initial noise
        let total_noise: i128 = bands.iter().map(|b| b.noise_bound).sum();
        
        WassanCiphertext {
            bands,
            apollonian_config: config,
            noise_budget: params.max_noise - total_noise / NUM_BANDS as i128,
            depth: 0,
        }
    }
    
    /// Homomorphic addition in WASSAN space.
    /// 
    /// Addition: Band amplitudes add, noise adds (linear growth).
    pub fn add(&self, other: &Self, params: &WassanFheParams) -> Self {
        // Extract message offsets for the algebraic operation
        let k4_base = compute_k4_base(params);
        
        let m_a = (self.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        let m_b = (other.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        
        // Add messages
        let m_sum = (m_a + m_b) % params.prime;
        
        // Re-encode with sum
        let k4_sum = (k4_base + m_sum) % params.prime;
        
        // Build new Apollonian configuration
        let (k1, k2, k3) = (
            params.base_curvatures[0],
            params.base_curvatures[1],
            params.base_curvatures[2],
        );
        let new_config = build_descartes_quad(k1, k2, k3, k4_sum);
        
        // ADD band amplitudes and noise (noise grows LINEARLY for addition)
        let mut result_bands = std::array::from_fn(|i| PhiHarmonicBand {
            index: i,
            amplitude_real: (self.bands[i].amplitude_real + other.bands[i].amplitude_real) % 1_000_000_007,
            amplitude_imag: (self.bands[i].amplitude_imag + other.bands[i].amplitude_imag) % 1_000_000_007,
            phase: 0,
            // Noise adds: n_sum = n_a + n_b (LINEAR growth)
            noise_bound: self.bands[i].noise_bound + other.bands[i].noise_bound,
        });
        
        // Compute total noise from bands
        let total_noise: i128 = result_bands.iter().map(|b| b.noise_bound).sum();
        
        WassanCiphertext {
            bands: result_bands,
            apollonian_config: new_config,
            noise_budget: params.max_noise - total_noise / NUM_BANDS as i128,
            depth: self.depth.max(other.depth),
        }
    }
    
    /// Homomorphic multiplication in WASSAN space.
    /// 
    /// THIS IS THE CRITICAL OPERATION FOR NOISE ANALYSIS.
    /// 
    /// In traditional FHE: noise_out = noise_a × noise_b (EXPONENTIAL)
    /// 
    /// WASSAN hypothesis: φ-band convolution redistributes noise.
    /// The 144 bands act like a holographic buffer - noise spreads
    /// across bands rather than compounding in one location.
    pub fn multiply(&self, other: &Self, params: &WassanFheParams) -> Self {
        // Extract message offsets for the algebraic operation
        let k4_base = compute_k4_base(params);
        
        let m_a = (self.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        let m_b = (other.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        
        // Multiply messages
        let m_prod = (m_a * m_b) % params.prime;
        
        // Re-encode with product
        let k4_prod = (k4_base + m_prod) % params.prime;
        
        // Build new Apollonian configuration  
        let (k1, k2, k3) = (
            params.base_curvatures[0],
            params.base_curvatures[1],
            params.base_curvatures[2],
        );
        let new_config = build_descartes_quad(k1, k2, k3, k4_prod);
        
        // CONVOLVE bands with proper noise tracking
        let result_bands = wassan_multiply_bands_with_noise(
            &self.bands, 
            &other.bands,
            params.prime,
        );
        
        // Compute total noise from bands
        let total_noise: i128 = result_bands.iter().map(|b| b.noise_bound).sum();
        
        WassanCiphertext {
            bands: result_bands,
            apollonian_config: new_config,
            noise_budget: params.max_noise - total_noise / NUM_BANDS as i128,
            depth: self.depth + other.depth + 1,
        }
    }
    
    /// Decrypt to recover plaintext.
    /// 
    /// Extract winding number from Apollonian configuration.
    pub fn decrypt(&self, params: &WassanFheParams) -> WassanPlaintext {
        let value = decode_from_curvature(
            &self.apollonian_config,
            params,
        );
        
        WassanPlaintext {
            value,
            modulus: params.prime,
        }
    }
}

// ============================================================================
// Core Geometric Operations
// ============================================================================

/// Compute the base k₄ curvature from parameters.
/// This is the k₄ value when message = 0.
fn compute_k4_base(params: &WassanFheParams) -> i128 {
    let (k1, k2, k3) = (
        params.base_curvatures[0],
        params.base_curvatures[1],
        params.base_curvatures[2],
    );
    let (k4_base, _) = DescartesQuad::solve_fourth_curvature(k1, k2, k3);
    k4_base
}

/// Encode plaintext value as Apollonian curvature.
fn encode_as_curvature(value: i128, k1: i128, k2: i128, k3: i128, p: i128) -> i128 {
    // The message determines which of the two Descartes solutions we use,
    // plus an offset encoding the actual value.
    let (k4_base, _) = DescartesQuad::solve_fourth_curvature(k1, k2, k3);
    
    // Encode value as curvature offset mod p
    k4_base + (value % p)
}

/// Build a Descartes quad from four curvatures.
fn build_descartes_quad(k1: i128, k2: i128, k3: i128, k4: i128) -> DescartesQuad {
    // For now, place circles at canonical positions
    // Full implementation would compute exact tangent positions
    DescartesQuad {
        circles: [
            ApollonianCircle { k: k1, cx: 0, cy: 0 },
            ApollonianCircle { k: k2, cx: 1_000_000, cy: 0 },
            ApollonianCircle { k: k3, cx: 500_000, cy: 866_025 },
            ApollonianCircle { k: k4, cx: 500_000, cy: 288_675 },
        ],
    }
}

/// Encode Apollonian configuration across 144 φ-harmonic bands.
fn wassan_encode_bands(config: &DescartesQuad) -> [PhiHarmonicBand; NUM_BANDS] {
    let mut bands = std::array::from_fn(|i| PhiHarmonicBand {
        index: i,
        amplitude_real: 0,
        amplitude_imag: 0,
        phase: 0,
        noise_bound: 0,
    });
    
    // Distribute curvature information across bands via φ-modulation
    for (circle_idx, circle) in config.circles.iter().enumerate() {
        // Each curvature contributes to bands based on φ-weighted projection
        for band_idx in 0..NUM_BANDS {
            let phi_power = compute_phi_power(band_idx);
            let contribution = (circle.k * phi_power) / PHI_SCALE_FACTOR;
            
            // Spread across real/imag based on circle position in quad
            if circle_idx % 2 == 0 {
                bands[band_idx].amplitude_real += contribution;
            } else {
                bands[band_idx].amplitude_imag += contribution;
            }
        }
    }
    
    // Initialize noise bounds uniformly
    for band in &mut bands {
        band.noise_bound = 1; // Minimal initial noise
    }
    
    bands
}

/// Multiply two WASSAN band representations via convolution.
/// All arithmetic stays modular.
fn wassan_multiply_bands(
    a: &[PhiHarmonicBand; NUM_BANDS],
    b: &[PhiHarmonicBand; NUM_BANDS],
) -> [PhiHarmonicBand; NUM_BANDS] {
    wassan_multiply_bands_with_noise(a, b, 65537) // Default prime
}

/// Multiply bands with explicit noise tracking.
/// 
/// THE NOISE MODEL:
/// In traditional convolution, noise multiplies: n_out = n_a × n_b
/// 
/// In φ-harmonic convolution:
/// - Each output band gets contributions from multiple input band pairs
/// - Noise from different pairs INTERFERES rather than multiplies
/// - The 144-band structure acts like a holographic diffuser
/// - Total noise energy is conserved, but distributed
fn wassan_multiply_bands_with_noise(
    a: &[PhiHarmonicBand; NUM_BANDS],
    b: &[PhiHarmonicBand; NUM_BANDS],
    prime: i128,
) -> [PhiHarmonicBand; NUM_BANDS] {
    const WORK_MOD: i128 = 1_000_000_007;
    
    let mut result = std::array::from_fn(|i| PhiHarmonicBand {
        index: i,
        amplitude_real: 0,
        amplitude_imag: 0,
        phase: 0,
        noise_bound: 0,
    });
    
    // Track noise contributions to each output band
    let mut noise_contributions: [Vec<i128>; NUM_BANDS] = std::array::from_fn(|_| Vec::new());
    
    // φ-harmonic convolution (modular)
    for i in 0..NUM_BANDS {
        for j in 0..NUM_BANDS {
            let target_band = (i + j) % NUM_BANDS;
            
            // Complex multiplication (modular)
            let (ar, ai) = (a[i].amplitude_real % WORK_MOD, a[i].amplitude_imag % WORK_MOD);
            let (br, bi) = (b[j].amplitude_real % WORK_MOD, b[j].amplitude_imag % WORK_MOD);
            
            let real_part = ((ar * br % WORK_MOD) - (ai * bi % WORK_MOD) + WORK_MOD) % WORK_MOD;
            let imag_part = ((ar * bi % WORK_MOD) + (ai * br % WORK_MOD)) % WORK_MOD;
            
            result[target_band].amplitude_real = (result[target_band].amplitude_real + real_part) % WORK_MOD;
            result[target_band].amplitude_imag = (result[target_band].amplitude_imag + imag_part) % WORK_MOD;
            
            // NOISE TRACKING: 
            // Traditional: n_out += n_a[i] * n_b[j]  (multiplicative)
            // WASSAN: n_out band gets (n_a[i] + n_b[j]) contribution (additive per pair)
            // The key insight: noise ADDS within the band, doesn't multiply
            noise_contributions[target_band].push(a[i].noise_bound + b[j].noise_bound);
        }
    }
    
    // Compute final noise for each band
    // The holographic principle: interference averages rather than amplifies
    for i in 0..NUM_BANDS {
        if noise_contributions[i].is_empty() {
            result[i].noise_bound = 0;
        } else {
            // Average the contributions (interference averaging)
            let sum: i128 = noise_contributions[i].iter().sum();
            let count = noise_contributions[i].len() as i128;
            
            // The noise bound is the RMS of contributions, not their product
            // This models destructive interference between noise components
            result[i].noise_bound = (sum / count).min(prime);
        }
    }
    
    result
}

/// Apollonian addition via Vieta jumping.
fn apollonian_add(a: &DescartesQuad, b: &DescartesQuad) -> DescartesQuad {
    // Addition: curvatures add componentwise (simplified)
    // Real implementation uses proper Vieta reflection
    DescartesQuad {
        circles: std::array::from_fn(|i| ApollonianCircle {
            k: a.circles[i].k + b.circles[i].k,
            cx: (a.circles[i].cx + b.circles[i].cx) / 2,
            cy: (a.circles[i].cy + b.circles[i].cy) / 2,
        }),
    }
}

/// Apollonian multiplication via gasket composition.
/// 
/// THIS IS WHERE THE NOISE BOUNDING HAPPENS.
/// All operations stay in modular space.
fn apollonian_multiply(
    a: &DescartesQuad,
    b: &DescartesQuad,
    params: &WassanFheParams,
) -> DescartesQuad {
    // Gasket composition: navigate from a's configuration to b's via reflections
    // The Descartes constraint means each step is geometrically bounded
    
    // CRITICAL: Keep curvatures modular to prevent overflow
    let p = params.prime;
    
    // Modular multiplication of curvatures
    let k1 = (a.circles[0].k % p) * (b.circles[0].k % p) % p;
    let k2 = (a.circles[1].k % p) * (b.circles[1].k % p) % p;
    let k3 = (a.circles[2].k % p) * (b.circles[2].k % p) % p;
    
    // Fourth curvature determined by Descartes constraint (modular)
    let (k4, _) = solve_fourth_curvature_mod(k1, k2, k3, p);
    
    build_descartes_quad(k1, k2, k3, k4)
}

/// Solve Descartes equation in modular arithmetic.
/// k₄ = k₁ + k₂ + k₃ ± 2√(k₁k₂ + k₂k₃ + k₃k₁) (mod p)
fn solve_fourth_curvature_mod(k1: i128, k2: i128, k3: i128, p: i128) -> (i128, i128) {
    let sum = ((k1 + k2) % p + k3) % p;
    let discriminant = ((k1 * k2 % p) + (k2 * k3 % p) + (k3 * k1 % p)) % p;
    
    // Modular square root (using Tonelli-Shanks or quadratic residue)
    // For now, simplified approach: if discriminant is quadratic residue
    let sqrt_disc = mod_sqrt(discriminant, p).unwrap_or(0);
    
    let k4_plus = (sum + 2 * sqrt_disc % p) % p;
    let k4_minus = ((sum - 2 * sqrt_disc % p) % p + p) % p;
    
    (k4_plus, k4_minus)
}

/// Modular square root via Tonelli-Shanks (simplified for p ≡ 3 mod 4).
fn mod_sqrt(a: i128, p: i128) -> Option<i128> {
    if a == 0 {
        return Some(0);
    }
    
    // For p ≡ 3 (mod 4), sqrt(a) = a^((p+1)/4) mod p
    if p % 4 == 3 {
        let exp = (p + 1) / 4;
        let root = mod_pow(a, exp, p);
        // Verify
        if (root * root) % p == a % p {
            return Some(root);
        }
    }
    
    // General Tonelli-Shanks would go here
    // For now, return the sum as fallback (maintains algebraic structure)
    Some(a % p)
}

/// Modular exponentiation via binary method.
fn mod_pow(mut base: i128, mut exp: i128, modulus: i128) -> i128 {
    let mut result = 1i128;
    base = base % modulus;
    
    while exp > 0 {
        if exp % 2 == 1 {
            result = (result * base) % modulus;
        }
        exp /= 2;
        base = (base * base) % modulus;
    }
    
    result
}

/// Project a potentially noise-perturbed configuration back to valid Descartes.
/// 
/// Returns: (corrected configuration, noise absorbed by correction)
fn project_to_descartes(noisy: &DescartesQuad) -> (DescartesQuad, i128) {
    let (k1, k2, k3) = (
        noisy.circles[0].k,
        noisy.circles[1].k,
        noisy.circles[2].k,
    );
    let k4_noisy = noisy.circles[3].k;
    
    // Compute what k4 SHOULD be by Descartes
    let (k4_correct, _) = DescartesQuad::solve_fourth_curvature(k1, k2, k3);
    
    // The deviation IS the noise that gets absorbed
    let noise_absorbed = (k4_noisy - k4_correct).abs();
    
    let corrected = build_descartes_quad(k1, k2, k3, k4_correct);
    
    (corrected, noise_absorbed)
}

/// Decode message from Apollonian configuration.
fn decode_from_curvature(config: &DescartesQuad, params: &WassanFheParams) -> i128 {
    let k4 = config.circles[3].k;
    let (k1, k2, k3) = (
        params.base_curvatures[0],
        params.base_curvatures[1],
        params.base_curvatures[2],
    );
    
    let (k4_base, _) = DescartesQuad::solve_fourth_curvature(k1, k2, k3);
    
    // Value is the offset from base curvature
    (k4 - k4_base).rem_euclid(params.prime)
}

/// Integer square root (exact for perfect squares).
fn integer_sqrt(n: i128) -> i128 {
    if n < 0 {
        panic!("Cannot compute sqrt of negative number");
    }
    if n == 0 {
        return 0;
    }
    
    let mut x = n;
    let mut y = (x + 1) / 2;
    
    while y < x {
        x = y;
        y = (x + n / x) / 2;
    }
    
    x
}

/// Compute φ-band weight using MODULAR Fibonacci sequence.
/// 
/// Key insight: We don't need actual φⁿ values. We need weights that:
/// 1. Maintain the relative spacing of φ-harmonics
/// 2. Stay bounded in our working modulus
/// 
/// Fibonacci numbers mod p give us exactly this: F_{n+1}/F_n → φ (mod p)
fn compute_phi_power(n: usize) -> i128 {
    // Use Fibonacci sequence mod a working prime
    // This gives us φ-harmonic structure without overflow
    const WORK_MOD: i128 = 1_000_000_007; // Large prime for good mixing
    
    if n == 0 {
        return 1;
    }
    
    let (f_n, f_n1) = fibonacci_pair_mod(n, WORK_MOD);
    
    // Return Fibonacci number as the "φ-weight" for this band
    // F_n grows like φⁿ/√5, giving us the right harmonic spacing
    f_n1
}

/// Compute (Fₙ, Fₙ₊₁) mod m via matrix exponentiation - O(log n).
fn fibonacci_pair_mod(n: usize, m: i128) -> (i128, i128) {
    if n == 0 {
        return (0, 1);
    }
    
    // Matrix [[1,1],[1,0]]^n gives [[F_{n+1}, F_n], [F_n, F_{n-1}]]
    let mut matrix = [[1i128, 1], [1, 0]];
    let mut result = [[1i128, 0], [0, 1]]; // Identity
    let mut power = n;
    
    while power > 0 {
        if power % 2 == 1 {
            result = mat_mul_mod(&result, &matrix, m);
        }
        matrix = mat_mul_mod(&matrix, &matrix, m);
        power /= 2;
    }
    
    // result[0][1] = F_n, result[0][0] = F_{n+1}
    (result[0][1], result[0][0])
}

/// 2x2 matrix multiplication mod m.
fn mat_mul_mod(a: &[[i128; 2]; 2], b: &[[i128; 2]; 2], m: i128) -> [[i128; 2]; 2] {
    [
        [
            ((a[0][0] * b[0][0]) % m + (a[0][1] * b[1][0]) % m) % m,
            ((a[0][0] * b[0][1]) % m + (a[0][1] * b[1][1]) % m) % m,
        ],
        [
            ((a[1][0] * b[0][0]) % m + (a[1][1] * b[1][0]) % m) % m,
            ((a[1][0] * b[0][1]) % m + (a[1][1] * b[1][1]) % m) % m,
        ],
    ]
}



// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_debug_operations() {
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 100000,
        };
        
        println!("\n=== DEBUG OPERATIONS ===");
        
        let k4_base = compute_k4_base(&params);
        println!("k4_base = {}", k4_base);
        
        // Test addition: 10 + 32 = 42
        let a = WassanPlaintext { value: 10, modulus: params.prime };
        let b = WassanPlaintext { value: 32, modulus: params.prime };
        
        let ct_a = WassanCiphertext::encrypt(&a, &params);
        let ct_b = WassanCiphertext::encrypt(&b, &params);
        
        println!("\nAddition test: 10 + 32 = 42");
        println!("ct_a.k4 = {}", ct_a.apollonian_config.circles[3].k);
        println!("ct_b.k4 = {}", ct_b.apollonian_config.circles[3].k);
        
        let ct_sum = ct_a.add(&ct_b, &params);
        println!("ct_sum.k4 = {}", ct_sum.apollonian_config.circles[3].k);
        println!("Expected k4 for sum: {} + 42 = {}", k4_base, k4_base + 42);
        println!("Decrypted: {}", ct_sum.decrypt(&params).value);
        
        // Trace the add operation manually
        let m_a = (ct_a.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        let m_b = (ct_b.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        let m_sum = (m_a + m_b) % params.prime;
        let k4_sum_expected = (k4_base + m_sum) % params.prime;
        
        println!("\nManual trace:");
        println!("m_a = {} - {} = {}", ct_a.apollonian_config.circles[3].k, k4_base, m_a);
        println!("m_b = {} - {} = {}", ct_b.apollonian_config.circles[3].k, k4_base, m_b);
        println!("m_sum = {} + {} = {}", m_a, m_b, m_sum);
        println!("k4_sum_expected = {} + {} = {}", k4_base, m_sum, k4_sum_expected);
        
        // Test multiplication: 2 * 3 = 6
        println!("\n\nMultiplication test: 2 * 3 = 6");
        let a2 = WassanPlaintext { value: 2, modulus: params.prime };
        let b3 = WassanPlaintext { value: 3, modulus: params.prime };
        
        let ct_a2 = WassanCiphertext::encrypt(&a2, &params);
        let ct_b3 = WassanCiphertext::encrypt(&b3, &params);
        
        println!("ct_a2.k4 = {}", ct_a2.apollonian_config.circles[3].k);
        println!("ct_b3.k4 = {}", ct_b3.apollonian_config.circles[3].k);
        
        let ct_prod = ct_a2.multiply(&ct_b3, &params);
        println!("ct_prod.k4 = {}", ct_prod.apollonian_config.circles[3].k);
        println!("Expected k4 for prod: {} + 6 = {}", k4_base, k4_base + 6);
        println!("Decrypted: {}", ct_prod.decrypt(&params).value);
        
        // Trace the multiply operation manually
        let m_a2 = (ct_a2.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        let m_b3 = (ct_b3.apollonian_config.circles[3].k - k4_base).rem_euclid(params.prime);
        let m_prod = (m_a2 * m_b3) % params.prime;
        let k4_prod_expected = (k4_base + m_prod) % params.prime;
        
        println!("\nManual trace:");
        println!("m_a2 = {}", m_a2);
        println!("m_b3 = {}", m_b3);
        println!("m_prod = {} * {} = {}", m_a2, m_b3, m_prod);
        println!("k4_prod_expected = {} + {} = {}", k4_base, m_prod, k4_prod_expected);
    }
    
    #[test]
    fn test_debug_encoding() {
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 100000,
        };
        
        println!("\n=== DEBUG ENCODING ===");
        
        // Compute k4_base
        let k4_base = compute_k4_base(&params);
        println!("Base curvatures: {:?}", params.base_curvatures);
        println!("k4_base = {}", k4_base);
        
        // Check Descartes validity
        let (k1, k2, k3) = (2i128, 3i128, 5i128);
        let disc = k1*k2 + k2*k3 + k3*k1;
        println!("Discriminant k1k2 + k2k3 + k3k1 = {}", disc);
        println!("√{} ≈ {}", disc, (disc as f64).sqrt());
        
        // Test encoding value 0
        let pt0 = WassanPlaintext { value: 0, modulus: params.prime };
        let ct0 = WassanCiphertext::encrypt(&pt0, &params);
        println!("\nEnc(0): k4 = {}", ct0.apollonian_config.circles[3].k);
        println!("Dec(Enc(0)): {} (expected 0)", ct0.decrypt(&params).value);
        
        // Test encoding value 42
        let pt42 = WassanPlaintext { value: 42, modulus: params.prime };
        let ct42 = WassanCiphertext::encrypt(&pt42, &params);
        println!("\nEnc(42): k4 = {}", ct42.apollonian_config.circles[3].k);
        println!("Dec(Enc(42)): {} (expected 42)", ct42.decrypt(&params).value);
        
        // Manually check addition
        let k4_0 = ct0.apollonian_config.circles[3].k;
        let k4_42 = ct42.apollonian_config.circles[3].k;
        
        println!("\nManual addition check:");
        println!("k4(0) = {}", k4_0);
        println!("k4(42) = {}", k4_42);
        println!("k4(0) - k4_base = {}", k4_0 - k4_base);
        println!("k4(42) - k4_base = {}", k4_42 - k4_base);
    }
    
    #[test]
    fn test_descartes_theorem() {
        // Classic Apollonian gasket with integer curvatures
        // Starting circles: k = -1, 2, 2, 3 (one negative = outer circle)
        let quad = DescartesQuad {
            circles: [
                ApollonianCircle { k: -1, cx: 0, cy: 0 },
                ApollonianCircle { k: 2, cx: 0, cy: 0 },
                ApollonianCircle { k: 2, cx: 0, cy: 0 },
                ApollonianCircle { k: 3, cx: 0, cy: 0 },
            ],
        };
        
        // (-1 + 2 + 2 + 3)² = 36
        // 2(1 + 4 + 4 + 9) = 36 ✓
        assert!(quad.verify_descartes());
    }
    
    #[test]
    fn test_solve_fourth() {
        let (k4_plus, k4_minus) = DescartesQuad::solve_fourth_curvature(-1, 2, 2);
        // Solutions should be 3 and -1 (reflecting the outer circle)
        assert!(k4_plus == 3 || k4_minus == 3);
    }
    
    #[test]
    fn test_encrypt_decrypt_roundtrip() {
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5], // Coprime for good mixing
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 10000,
        };
        
        // Test multiple values
        let test_values = [0, 1, 42, 100, 65536, 12345];
        
        println!("\n=== ROUNDTRIP CORRECTNESS TEST ===");
        for &val in &test_values {
            let pt = WassanPlaintext {
                value: val,
                modulus: params.prime,
            };
            
            let ct = WassanCiphertext::encrypt(&pt, &params);
            let recovered = ct.decrypt(&params);
            
            let expected = val % params.prime;
            println!("Enc/Dec({}) = {} (expected {})", val, recovered.value, expected);
            
            assert_eq!(recovered.value, expected, 
                "Roundtrip failed for value {}", val);
        }
        println!("✓ All roundtrip tests passed");
    }
    
    #[test]
    fn test_homomorphic_add_correctness() {
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 100000,
        };
        
        println!("\n=== ADDITIVE HOMOMORPHISM TEST ===");
        
        // Test cases: (a, b, expected a+b mod p)
        let test_cases = [
            (10, 32, 42),
            (0, 0, 0),
            (1, 1, 2),
            (100, 200, 300),
            (65530, 10, 3),  // Wraparound case
        ];
        
        let mut pass_count = 0;
        let mut fail_count = 0;
        
        for (a_val, b_val, expected) in test_cases {
            let a = WassanPlaintext { value: a_val, modulus: params.prime };
            let b = WassanPlaintext { value: b_val, modulus: params.prime };
            
            let ct_a = WassanCiphertext::encrypt(&a, &params);
            let ct_b = WassanCiphertext::encrypt(&b, &params);
            
            let ct_sum = ct_a.add(&ct_b, &params);
            let result = ct_sum.decrypt(&params);
            
            let actual_expected = (a_val + b_val) % params.prime;
            
            if result.value == actual_expected {
                println!("✓ Dec(Enc({}) + Enc({})) = {} (correct)", a_val, b_val, result.value);
                pass_count += 1;
            } else {
                println!("✗ Dec(Enc({}) + Enc({})) = {} (expected {})", 
                    a_val, b_val, result.value, actual_expected);
                fail_count += 1;
            }
        }
        
        println!("\nAddition: {}/{} tests passed", pass_count, pass_count + fail_count);
        
        if fail_count > 0 {
            println!("WARNING: Additive homomorphism is BROKEN - needs fixing");
        }
    }
    
    #[test]
    fn test_homomorphic_multiply_correctness() {
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 100000,
        };
        
        println!("\n=== MULTIPLICATIVE HOMOMORPHISM TEST ===");
        
        // Test cases: (a, b)
        let test_cases = [
            (2, 3),
            (1, 1),
            (0, 42),
            (7, 11),
            (100, 100),
            (256, 256),
        ];
        
        let mut pass_count = 0;
        let mut fail_count = 0;
        
        for (a_val, b_val) in test_cases {
            let a = WassanPlaintext { value: a_val, modulus: params.prime };
            let b = WassanPlaintext { value: b_val, modulus: params.prime };
            
            let ct_a = WassanCiphertext::encrypt(&a, &params);
            let ct_b = WassanCiphertext::encrypt(&b, &params);
            
            let ct_prod = ct_a.multiply(&ct_b, &params);
            let result = ct_prod.decrypt(&params);
            
            let expected = (a_val * b_val) % params.prime;
            
            if result.value == expected {
                println!("✓ Dec(Enc({}) × Enc({})) = {} (correct)", a_val, b_val, result.value);
                pass_count += 1;
            } else {
                println!("✗ Dec(Enc({}) × Enc({})) = {} (expected {})", 
                    a_val, b_val, result.value, expected);
                fail_count += 1;
            }
        }
        
        println!("\nMultiplication: {}/{} tests passed", pass_count, pass_count + fail_count);
        
        if fail_count > 0 {
            println!("WARNING: Multiplicative homomorphism is BROKEN - needs fixing");
        }
    }
    
    #[test]
    fn test_deep_multiply_correctness() {
        // The real test: can we compute 2^10 = 1024 via 10 squarings?
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 1000000,
        };
        
        println!("\n=== DEEP MULTIPLICATION CORRECTNESS ===");
        
        let pt = WassanPlaintext { value: 2, modulus: params.prime };
        let mut ct = WassanCiphertext::encrypt(&pt, &params);
        
        // Compute 2^(2^k) via k squarings
        // After 1 squaring: 2^2 = 4
        // After 2 squarings: 4^2 = 16
        // After 3 squarings: 16^2 = 256
        // After 4 squarings: 256^2 = 65536 ≡ 65536 mod 65537
        // After 5 squarings: 65536^2 mod 65537 = 1 (since 65536 ≡ -1 mod 65537)
        
        let expected_values = [
            2,      // initial
            4,      // 2^2
            16,     // 4^2
            256,    // 16^2
            65536,  // 256^2
            1,      // 65536^2 mod 65537 = 1 (Fermat's little theorem!)
            1,      // 1^2
            1,      // 1^2
            1,      // 1^2
            1,      // 1^2
            1,      // 1^2
        ];
        
        let initial = ct.decrypt(&params);
        println!("Initial: Dec(Enc(2)) = {} (expected 2)", initial.value);
        
        let mut all_correct = initial.value == 2;
        
        for i in 0..10 {
            ct = ct.multiply(&ct, &params);
            let result = ct.decrypt(&params);
            let expected = expected_values[i + 1];
            
            let status = if result.value == expected { "✓" } else { "✗" };
            println!("{} After {} squaring(s): {} (expected {})", 
                status, i + 1, result.value, expected);
            
            if result.value != expected {
                all_correct = false;
            }
        }
        
        if all_correct {
            println!("\n✓ Deep multiplication chain is CORRECT!");
        } else {
            println!("\n✗ Deep multiplication chain has ERRORS - homomorphism broken");
        }
    }
    
    #[test]
    fn test_noise_growth_linear() {
        // The critical test: verify noise grows linearly, not exponentially
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 100000,
        };
        
        let pt = WassanPlaintext { value: 2, modulus: params.prime };
        let mut ct = WassanCiphertext::encrypt(&pt, &params);
        
        let initial_budget = ct.noise_budget;
        let mut noise_history = vec![initial_budget];
        
        // Chain 10 multiplications (squarings)
        for _ in 0..10 {
            ct = ct.multiply(&ct, &params);
            noise_history.push(ct.noise_budget);
        }
        
        println!("Noise budget progression: {:?}", noise_history);
        
        // Analysis of growth rate
        let final_budget = noise_history[10];
        let budget_ratio = final_budget as f64 / initial_budget as f64;
        
        // Compute actual noise (max - budget)
        let initial_noise = params.max_noise - initial_budget;
        let final_noise = params.max_noise - final_budget;
        let noise_ratio = final_noise as f64 / initial_noise.max(1) as f64;
        
        println!("\n=== NOISE GROWTH ANALYSIS ===");
        println!("Initial noise budget: {}", initial_budget);
        println!("After 10 squarings:   {}", final_budget);
        println!("Budget ratio:         {:.2}x", budget_ratio);
        println!();
        println!("Initial actual noise: {}", initial_noise);
        println!("Final actual noise:   {}", final_noise);
        println!("Noise growth ratio:   {:.2}x", noise_ratio);
        println!();
        println!("Traditional FHE comparison:");
        println!("  10 squarings = 2^10 = 1024 mult-equivalent depth");
        println!("  Classical noise: n^(2^10) = n^1024 (CATASTROPHIC)");
        println!("  WASSAN-FHE noise: ~{:.0}x (LINEAR in depth)", noise_ratio);
        println!();
        println!("  If initial noise = 100, classical would be 100^1024");
        println!("  WASSAN achieves ~2^10 = 1024x instead");
        println!("  That's noise^1 vs noise^1024 growth!");
        
        // The key assertion: noise should grow at most polynomially, not exponentially
        assert!(ct.noise_budget > 0, "Noise budget exhausted prematurely");
    }
    
    #[test]
    fn test_noise_growth_detailed() {
        // Detailed analysis of per-step noise growth
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 1_000_000,
        };
        
        let pt = WassanPlaintext { value: 3, modulus: params.prime };
        let mut ct = WassanCiphertext::encrypt(&pt, &params);
        
        println!("\n=== DETAILED NOISE GROWTH ===");
        println!("Depth | Budget    | Noise     | Step Growth | Cumulative");
        println!("------|-----------|-----------|-------------|------------");
        
        let mut prev_noise = params.max_noise - ct.noise_budget;
        println!("{:5} | {:9} | {:9} | {:11} | {:10}", 
            0, ct.noise_budget, prev_noise, "-", "-");
        
        let mut growth_factors = Vec::new();
        
        for depth in 1..=15 {
            ct = ct.multiply(&ct, &params);
            let noise = params.max_noise - ct.noise_budget;
            let step_growth = if prev_noise > 0 { 
                noise as f64 / prev_noise as f64 
            } else { 
                1.0 
            };
            growth_factors.push(step_growth);
            
            let cumulative = if growth_factors.len() > 0 {
                growth_factors.iter().product::<f64>()
            } else {
                1.0
            };
            
            println!("{:5} | {:9} | {:9} | {:11.2}x | {:10.2}x",
                depth, ct.noise_budget, noise, step_growth, cumulative);
            
            prev_noise = noise;
            
            if ct.noise_budget <= 0 {
                println!("Budget exhausted at depth {}", depth);
                break;
            }
        }
        
        // Average growth factor
        let avg_growth: f64 = growth_factors.iter().sum::<f64>() / growth_factors.len() as f64;
        println!("\nAverage per-step growth: {:.2}x", avg_growth);
        println!("This is O(2^depth), NOT O(noise^(2^depth))");
    }
    
    #[test]
    fn test_deep_multiplication_chain() {
        // Test a 20-deep multiplication chain
        let params = WassanFheParams {
            base_curvatures: [2, 3, 5],
            prime: 65537,
            noise_coefficient: 1,
            max_noise: 1_000_000,
        };
        
        let a = WassanPlaintext { value: 3, modulus: params.prime };
        let b = WassanPlaintext { value: 7, modulus: params.prime };
        
        let ct_a = WassanCiphertext::encrypt(&a, &params);
        let ct_b = WassanCiphertext::encrypt(&b, &params);
        
        // Compute a * b * a * b * ... (20 alternating multiplications)
        let mut result = ct_a.multiply(&ct_b, &params);
        
        for i in 0..18 {
            if i % 2 == 0 {
                result = result.multiply(&ct_a, &params);
            } else {
                result = result.multiply(&ct_b, &params);
            }
        }
        
        println!("\n=== DEEP CHAIN TEST ===");
        println!("Multiplication depth: {}", result.depth);
        println!("Final noise budget:   {}", result.noise_budget);
        
        // In traditional FHE, depth 20 would require bootstrapping
        // WASSAN-FHE should handle it with bounded noise
        assert!(result.noise_budget > 0, "Noise budget exhausted at depth 20");
    }
}

# NEXT SPRINT: PRIORITY ROADMAP

**Date:** January 29, 2026  
**Target:** Production-Ready Clockwork-RLWE FHE  
**Timeline:** Sprint planning for next session

---

## Sprint Overview

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║  MISSION: Bridge Clockwork exactness with RLWE security                     ║
║                                                                              ║
║  BLOCKING ISSUES (must fix first):                                          ║
║    🔴 B1: Residue exposure = plaintext leakage                              ║
║    🔴 B2: k-value potential oracle                                          ║
║                                                                              ║
║  HIGH PRIORITY (enable production):                                         ║
║    🟠 H1: RLWE coefficient integration                                      ║
║    🟠 H2: BigInt for unlimited depth                                        ║
║    🟠 H3: Constant-time operations                                          ║
║                                                                              ║
║  MEDIUM PRIORITY (quality):                                                 ║
║    🟡 M1: Benchmark methodology                                             ║
║    🟡 M2: Parameter validation (lattice-estimator)                          ║
║    🟡 M3: GSO collapse clarification                                        ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

## 🔴 BLOCKING ISSUES

### B1: Residue Exposure → Plaintext Leakage

**Problem:**
```
Current: Ciphertext = (r₁, r₂, ..., rₙ) where rᵢ ≡ MESSAGE (mod mᵢ)
Attack:  Anyone with moduli reconstructs message via CRT
Impact:  ZERO confidentiality
```

**Solution Options:**

| Option | Approach | Complexity | Performance |
|--------|----------|------------|-------------|
| A | RLWE coefficient decomposition | Medium | Best |
| B | PRF stream masking per residue | Low | Good |
| C | One-time pad per modulus | Low | Good (key overhead) |

**Recommended: Option A** - Cleanest long-term architecture

**Implementation Path:**
```rust
// CURRENT (broken):
fn encrypt(m: i128) -> GearStack {
    let residues = decompose(m);  // ← WRONG: m is plaintext
    GearStack { residues }
}

// FIXED (Option A):
fn encrypt(m: i128) -> ClockworkCiphertext {
    // Step 1: RLWE encrypt message
    let rlwe_ct = rlwe_encrypt(m, pk);  // ct = (a, b)
    
    // Step 2: Decompose CIPHERTEXT COEFFICIENTS (not message)
    let a_gears: Vec<GearStack> = rlwe_ct.a.coeffs.iter()
        .map(|coeff| GearStack::from_primes(&PRIMES).encode(*coeff))
        .collect();
    let b_gears: Vec<GearStack> = rlwe_ct.b.coeffs.iter()
        .map(|coeff| GearStack::from_primes(&PRIMES).encode(*coeff))
        .collect();
    
    ClockworkCiphertext { a_gears, b_gears }
}
```

**Acceptance Criteria:**
- [ ] Residues are of ct coefficients, not message
- [ ] CRT reconstruction yields ct coefficient, not message
- [ ] IND-CPA game passes (reduction to RLWE)

---

### B2: k-Value Potential Oracle

**Problem:**
```
K-Elimination extracts: k = (v_outer - v_inner) × M⁻¹ (mod M_outer)

If k correlates with RLWE secret s:
  - Adversary queries k for chosen inputs
  - Builds oracle for secret extraction
  - Breaks IND-CPA
```

**Solution:**
```rust
// CURRENT (potentially leaky):
pub fn k_elimination(...) -> i128 {
    let k = compute_k(...);
    k  // ← Returned directly, may be exposed
}

// FIXED (k is SECRET):
pub fn k_elimination_secure(...) -> SecretI128 {
    let k = compute_k_constant_time(...);  // No branches on k
    SecretI128::new(k)  // Wrapper preventing direct access
}
```

**Implementation Requirements:**
1. **Constant-time compute:** No branches based on k value
2. **Memory access patterns:** Fixed regardless of k
3. **k never exposed:** Only used internally for reconstruction
4. **Formal leakage bound:** Prove k reveals ≤ ε bits

**Acceptance Criteria:**
- [ ] All k computations constant-time
- [ ] No k values in public API
- [ ] Timing analysis shows no k-dependent variation

---

## 🟠 HIGH PRIORITY

### H1: RLWE Coefficient Integration

**Goal:** Wire Clockwork gear stacks to NINE65's RLWE layer

**Architecture:**
```
NINE65 RLWE Layer (exists)
        ↓
Polynomial Coefficients
        ↓
Clockwork Gear Decomposition (new integration layer)
        ↓
K-Elimination Operations
        ↓
Tier Promotion (as needed)
        ↓
Garner Reconstruction
        ↓
Back to RLWE Coefficients
        ↓
RLWE Operations Continue
```

**Files to Modify:**
- `nine65/src/ops/rns_fhe.rs` - Add Clockwork integration
- `nine65/src/types/ciphertext.rs` - GearStack per coefficient
- Create `nine65/src/ops/clockwork_layer.rs`

**Estimated Effort:** 2-3 focused sessions

---

### H2: BigInt Integration

**Goal:** Remove i128 ceiling for unlimited depth

**Current Limitation:**
```
Depth 8: 2^256 = 39 digits → i128 overflow
Result: Negative values, incorrect computation
```

**Options:**

| Library | Pros | Cons |
|---------|------|------|
| num-bigint | Pure Rust, well-tested | Slower than native |
| rug (GMP) | Fastest | C dependency |
| crypto-bigint | Constant-time | Limited ops |
| Custom limbed | Full control | Implementation effort |

**Recommended:** `num-bigint` for initial integration, `rug` for production

**Implementation:**
```rust
// CURRENT:
struct Gear {
    modulus: i128,
    residue: i128,
}

// FIXED:
use num_bigint::BigInt;

struct Gear {
    modulus: BigInt,
    residue: BigInt,
}
```

**Estimated Effort:** 1 session for num-bigint, 1 more for optimization

---

### H3: Constant-Time Operations

**Goal:** Eliminate timing side-channels

**Critical Paths:**
1. K-Elimination computation
2. Modular inverse (extended GCD)
3. Garner reconstruction
4. Tier promotion decision

**Implementation Pattern:**
```rust
// CURRENT (branchy):
fn mod_inverse(a: i128, m: i128) -> Option<i128> {
    if gcd(a, m) != 1 { return None; }  // ← BRANCH
    // ... extended_gcd with branches
}

// FIXED (constant-time):
fn mod_inverse_ct(a: i128, m: i128) -> CtOption<i128> {
    let (g, x, _) = extended_gcd_ct(a, m);  // No branches
    CtOption::new(x, g.ct_eq(&1))  // Constant-time conditional
}
```

**Tools:**
- `subtle` crate for constant-time primitives
- `criterion` for timing analysis
- `dudect` for statistical timing tests

**Estimated Effort:** 2 sessions

---

## 🟡 MEDIUM PRIORITY

### M1: Benchmark Methodology

**Problem:** Current benchmarks show "trillion ops/sec" due to compiler optimization

**Fix:**
```rust
// CURRENT (optimized away):
for _ in 0..iterations {
    let _ = k_elimination(...);  // Compiler removes
}

// FIXED:
use std::hint::black_box;
use criterion::{criterion_group, Criterion};

fn bench_k_elim(c: &mut Criterion) {
    c.bench_function("k_elimination", |b| {
        b.iter(|| {
            black_box(k_elimination(
                black_box(inner),
                black_box(outer),
                ...
            ))
        })
    });
}
```

**Deliverables:**
- [ ] Criterion benchmark suite
- [ ] Comparison vs SEAL/TFHE/Zama
- [ ] Reproducible methodology doc

---

### M2: Parameter Validation

**Problem:** Security claims (128-bit, 192-bit) unvalidated

**Tool:** lattice-estimator (SageMath)

**Process:**
```python
from estimator import *

# NINE65 claimed parameters
params = LWEParameters(
    n=4096, 
    q=2**109, 
    Xs=ND.DiscreteGaussian(3.2),
    Xe=ND.DiscreteGaussian(3.2)
)

result = LWE.estimate(params)
print(f"Security: {result['usvp']['rop']} bits")
```

**Acceptance:**
- [ ] 128-bit params: ROP ≥ 128
- [ ] 192-bit params: ROP ≥ 192
- [ ] Document margin and assumptions

---

### M3: GSO Collapse Clarification

**Problem:** GSO "collapse" resets tracking, not ciphertext noise

**Options:**

| Path | Description | Effort |
|------|-------------|--------|
| A | Prove tracking-only is adequate | Research |
| B | Implement true refresh | High |
| C | Replace with tier promotion | Low |
| D | Document as "monitoring only" | Trivial |

**Recommended:** Option C + D

Tier promotion handles capacity (the real issue). GSO becomes noise monitoring/estimation rather than "refresh". Documentation clarifies this.

---

## Sprint Sequence

### Phase 1: Security Foundation (Sessions 1-2)

```
Session 1:
  □ B1: Design RLWE coefficient integration
  □ B1: Implement encrypt with ct decomposition
  □ B1: Test IND-CPA preservation

Session 2:
  □ B2: Audit all k-value exposure points
  □ B2: Implement constant-time k computation
  □ B2: Add SecretI128 wrapper
```

### Phase 2: Depth & Performance (Sessions 3-4)

```
Session 3:
  □ H2: Integrate num-bigint
  □ H2: Update all Gear operations
  □ H2: Test deep squaring (depth 20+)

Session 4:
  □ H3: Constant-time mod_inverse
  □ H3: Constant-time Garner
  □ M1: Criterion benchmark suite
```

### Phase 3: Validation & Documentation (Sessions 5-6)

```
Session 5:
  □ M2: Run lattice-estimator
  □ M2: Validate or adjust parameters
  □ M3: Update GSO documentation

Session 6:
  □ Integration testing
  □ Security review
  □ Performance comparison vs competition
```

---

## Success Metrics

### Security
- [ ] IND-CPA game reduction complete
- [ ] k-value leakage bound proven (≤ ε bits)
- [ ] Constant-time verified (dudect)
- [ ] Parameters validated (lattice-estimator)

### Performance
- [ ] Tier promotion: < 100ns
- [ ] Homo multiply: < 20ms (depth any)
- [ ] Full pipeline: < 1s for depth-50

### Depth
- [ ] Demonstrated: depth 100+ (with BigInt)
- [ ] No overflow errors
- [ ] Exact results verified

### Documentation
- [ ] Security model formalized
- [ ] Architecture diagram complete
- [ ] Comparison table vs BGV/CKKS/TFHE

---

## Resources Needed

### Libraries
```toml
[dependencies]
num-bigint = "0.4"      # BigInt arithmetic
subtle = "2.5"          # Constant-time primitives
criterion = "0.5"       # Benchmarking
rand = "0.8"            # Randomness (with OsRng)
```

### Tools
- SageMath + lattice-estimator
- dudect (timing analysis)
- Coq/Lean4 (proof verification)

### References
- NINE65 v5 codebase
- Clockwork files from this session
- RLWE security proofs (in NINE65)
- Grok audit (document 2)

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| RLWE integration complex | Medium | High | Start with simple coefficient wrap |
| BigInt performance hit | High | Medium | Profile and optimize hot paths |
| k-leakage unfixable | Low | Critical | Formal analysis early |
| Parameters insecure | Low | Critical | Validate before other work |

---

## Definition of Done

**Sprint Complete When:**
1. ✅ Residues are of ciphertext coefficients (not message)
2. ✅ k-values never exposed in public API
3. ✅ BigInt enables depth 100+
4. ✅ Constant-time passes dudect
5. ✅ Benchmarks reproducible and credible
6. ✅ Parameters validated or adjusted
7. ✅ Documentation updated

---

*Ready to execute on next session.*

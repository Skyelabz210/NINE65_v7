//! # CLOCKWORK-WASSAN FHE: COMPREHENSIVE TEST BATTERY
//!
//! Quality gates, stress tests, and data collection for the integrated system.
//!
//! ## Test Categories
//!
//! 1. **GATE 1: Algebraic Correctness** - Basic operations must be exact
//! 2. **GATE 2: K-Elimination Accuracy** - Phase differential must reconstruct perfectly
//! 3. **GATE 3: Homomorphic Properties** - Operations must preserve structure
//! 4. **GATE 4: Depth Stress Tests** - Deep chains must maintain correctness
//! 5. **GATE 5: Range Coverage** - Must work across full value range
//! 6. **GATE 6: Edge Cases** - Boundary conditions must be handled
//! 7. **GATE 7: Performance Metrics** - Must meet performance targets
//! 8. **GATE 8: Statistical Validation** - Phase differential distribution analysis
//!
//! ## Quality Gate Thresholds
//!
//! | Gate | Metric | Threshold | Criticality |
//! |------|--------|-----------|-------------|
//! | G1 | Correctness rate | 100% | BLOCKING |
//! | G2 | K-Elimination accuracy | 100% | BLOCKING |
//! | G3 | Homomorphic correctness | 100% | BLOCKING |
//! | G4 | Max verified depth | ≥100 | HIGH |
//! | G5 | Range coverage | Full modulus | HIGH |
//! | G6 | Edge case pass rate | 100% | BLOCKING |
//! | G7 | Ops/second | ≥10,000 | MEDIUM |
//! | G8 | Phase uniformity | χ² < threshold | LOW |

use std::time::{Instant, Duration};
use std::collections::HashMap;

// =============================================================================
// MATHEMATICAL PRIMITIVES (copied from main module for standalone execution)
// =============================================================================

fn extended_gcd(a: i128, b: i128) -> (i128, i128, i128) {
    if b == 0 {
        (a.abs(), a.signum(), 0)
    } else {
        let (g, x, y) = extended_gcd(b, a % b);
        (g, y, x - (a / b) * y)
    }
}

fn mod_inverse(a: i128, m: i128) -> Option<i128> {
    let (g, x, _) = extended_gcd(a, m);
    if g != 1 { None } else { Some(((x % m) + m) % m) }
}

fn k_elimination(
    inner_res: i128,
    outer_res: i128,
    inner_cap: i128,
    inner_inv_outer: i128,
    outer_cap: i128,
) -> i128 {
    let diff = (outer_res - inner_res).rem_euclid(outer_cap);
    (diff * inner_inv_outer).rem_euclid(outer_cap)
}

fn reconstruct_from_k(inner_res: i128, k: i128, inner_cap: i128) -> i128 {
    inner_res + k * inner_cap
}

fn garner_reconstruction(residues: &[i128], moduli: &[i128]) -> i128 {
    let n = residues.len();
    if n == 0 { return 0; }
    if n == 1 { return residues[0]; }
    
    let mut mixed_radix = vec![0i128; n];
    mixed_radix[0] = residues[0];
    
    for i in 1..n {
        let mut prefix_product = 1i128;
        for j in 0..i {
            prefix_product = prefix_product.saturating_mul(moduli[j]);
        }
        
        let mut partial_sum = mixed_radix[0];
        let mut term_product = 1i128;
        for j in 1..i {
            term_product = term_product.saturating_mul(moduli[j-1]);
            partial_sum = partial_sum.wrapping_add(mixed_radix[j].wrapping_mul(term_product));
        }
        
        let diff = (residues[i] - partial_sum).rem_euclid(moduli[i]);
        let inv = mod_inverse(prefix_product.rem_euclid(moduli[i]), moduli[i]).unwrap_or(1);
        mixed_radix[i] = (diff * inv).rem_euclid(moduli[i]);
    }
    
    let mut result = mixed_radix[0];
    let mut product = 1i128;
    for i in 1..n {
        product = product.saturating_mul(moduli[i-1]);
        result = result.wrapping_add(mixed_radix[i].wrapping_mul(product));
    }
    
    result
}

// =============================================================================
// TEST INFRASTRUCTURE
// =============================================================================

#[derive(Debug, Clone)]
struct TestResult {
    name: String,
    passed: bool,
    tests_run: u64,
    tests_passed: u64,
    duration_ms: f64,
    details: String,
    data: HashMap<String, f64>,
}

#[derive(Debug)]
struct QualityGate {
    name: String,
    threshold: f64,
    actual: f64,
    passed: bool,
    criticality: &'static str,
}

#[derive(Debug)]
struct TestBattery {
    results: Vec<TestResult>,
    gates: Vec<QualityGate>,
    total_tests: u64,
    total_passed: u64,
    total_duration_ms: f64,
}

impl TestBattery {
    fn new() -> Self {
        TestBattery {
            results: Vec::new(),
            gates: Vec::new(),
            total_tests: 0,
            total_passed: 0,
            total_duration_ms: 0.0,
        }
    }
    
    fn add_result(&mut self, result: TestResult) {
        self.total_tests += result.tests_run;
        self.total_passed += result.tests_passed;
        self.total_duration_ms += result.duration_ms;
        self.results.push(result);
    }
    
    fn add_gate(&mut self, gate: QualityGate) {
        self.gates.push(gate);
    }
    
    fn print_summary(&self) {
        println!("\n════════════════════════════════════════════════════════════════════════════════");
        println!("           CLOCKWORK-WASSAN FHE TEST BATTERY RESULTS");
        println!("════════════════════════════════════════════════════════════════════════════════\n");
        
        // Test Results
        println!("TEST RESULTS:");
        println!("────────────────────────────────────────────────────────────────────────────────");
        for result in &self.results {
            let status = if result.passed { "✓ PASS" } else { "✗ FAIL" };
            println!("{:50} {:>10} ({}/{}) [{:.2}ms]",
                result.name,
                status,
                result.tests_passed,
                result.tests_run,
                result.duration_ms
            );
        }
        
        // Quality Gates
        println!("\nQUALITY GATES:");
        println!("────────────────────────────────────────────────────────────────────────────────");
        for gate in &self.gates {
            let status = if gate.passed { "✓ PASS" } else { "✗ FAIL" };
            let crit_marker = match gate.criticality {
                "BLOCKING" => "🔴",
                "HIGH" => "🟠",
                "MEDIUM" => "🟡",
                _ => "🟢",
            };
            println!("{} {:40} {:>10} (actual: {:.4}, threshold: {:.4}) [{}]",
                crit_marker,
                gate.name,
                status,
                gate.actual,
                gate.threshold,
                gate.criticality
            );
        }
        
        // Summary
        println!("\n════════════════════════════════════════════════════════════════════════════════");
        println!("SUMMARY:");
        println!("  Total tests:  {} / {} passed ({:.2}%)",
            self.total_passed,
            self.total_tests,
            100.0 * self.total_passed as f64 / self.total_tests as f64
        );
        println!("  Total time:   {:.2} ms", self.total_duration_ms);
        
        let blocking_failures: Vec<_> = self.gates.iter()
            .filter(|g| g.criticality == "BLOCKING" && !g.passed)
            .collect();
        
        if blocking_failures.is_empty() {
            println!("\n  🎯 ALL BLOCKING GATES PASSED - SYSTEM VALIDATED");
        } else {
            println!("\n  ⚠️  BLOCKING GATE FAILURES:");
            for g in blocking_failures {
                println!("      - {}", g.name);
            }
        }
        println!("════════════════════════════════════════════════════════════════════════════════\n");
    }
}

// =============================================================================
// DUAL MANIFOLD CONFIGURATIONS FOR TESTING
// =============================================================================

struct DualManifold {
    inner_cap: i128,
    outer_cap: i128,
    inner_inv_outer: i128,
    total_cap: i128,
    name: String,
}

impl DualManifold {
    fn small() -> Self {
        // 7×11×13 = 1001, 17×19×23 = 7429
        let inner = 1001i128;
        let outer = 7429i128;
        DualManifold {
            inner_cap: inner,
            outer_cap: outer,
            inner_inv_outer: mod_inverse(inner % outer, outer).unwrap(),
            total_cap: inner * outer,
            name: "Small (1001 × 7429)".to_string(),
        }
    }
    
    fn medium() -> Self {
        // 7×11×13×17 = 17017, 19×23×29×31 = 392863
        let inner = 17017i128;
        let outer = 392863i128;
        DualManifold {
            inner_cap: inner,
            outer_cap: outer,
            inner_inv_outer: mod_inverse(inner % outer, outer).unwrap(),
            total_cap: inner * outer,
            name: "Medium (17017 × 392863)".to_string(),
        }
    }
    
    fn large() -> Self {
        // Larger primes for stress testing
        let inner = 2i128 * 3 * 5 * 7 * 11 * 13 * 17 * 19; // 9699690
        let outer = 23i128 * 29 * 31 * 37 * 41 * 43;        // 906994999... wait that's too big
        let outer = 23i128 * 29 * 31 * 37;                  // 762223
        DualManifold {
            inner_cap: inner,
            outer_cap: outer,
            inner_inv_outer: mod_inverse(inner % outer, outer).unwrap(),
            total_cap: inner.saturating_mul(outer),
            name: "Large (9699690 × 762223)".to_string(),
        }
    }
}

// =============================================================================
// GATE 1: ALGEBRAIC CORRECTNESS
// =============================================================================

fn test_gate1_algebraic_correctness(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    let manifold = DualManifold::small();
    
    // Test 1.1: Basic reconstruction
    let test_values: Vec<i128> = vec![
        0, 1, 2, 10, 100, 1000, 
        manifold.inner_cap - 1,
        manifold.inner_cap,
        manifold.inner_cap + 1,
        manifold.total_cap / 2,
        manifold.total_cap - 1,
    ];
    
    for &v in &test_values {
        total += 1;
        let v_mod = v % manifold.total_cap;
        let inner = v_mod % manifold.inner_cap;
        let outer = v_mod % manifold.outer_cap;
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let reconstructed = reconstruct_from_k(inner, k, manifold.inner_cap);
        
        if reconstructed % manifold.total_cap == v_mod {
            passed += 1;
        } else {
            details.push_str(&format!("FAIL: v={}, expected={}, got={}\n", v, v_mod, reconstructed));
        }
    }
    
    // Test 1.2: Addition correctness
    let add_pairs: Vec<(i128, i128)> = vec![
        (0, 0), (1, 1), (10, 20), (100, 200),
        (manifold.inner_cap - 1, 1),  // Wrap inner
        (manifold.outer_cap - 1, 1),  // Wrap outer
    ];
    
    for (a, b) in add_pairs {
        total += 1;
        let expected = (a + b) % manifold.total_cap;
        
        let a_inner = a % manifold.inner_cap;
        let a_outer = a % manifold.outer_cap;
        let b_inner = b % manifold.inner_cap;
        let b_outer = b % manifold.outer_cap;
        
        let sum_inner = (a_inner + b_inner) % manifold.inner_cap;
        let sum_outer = (a_outer + b_outer) % manifold.outer_cap;
        let k = k_elimination(sum_inner, sum_outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let result = reconstruct_from_k(sum_inner, k, manifold.inner_cap) % manifold.total_cap;
        
        if result == expected {
            passed += 1;
        } else {
            details.push_str(&format!("ADD FAIL: {}+{}={}, got {}\n", a, b, expected, result));
        }
    }
    
    // Test 1.3: Multiplication correctness
    let mul_pairs: Vec<(i128, i128)> = vec![
        (0, 0), (1, 1), (2, 3), (7, 11), (100, 100),
        (256, 256), (1000, 1000),
    ];
    
    for (a, b) in mul_pairs {
        total += 1;
        let expected = (a * b) % manifold.total_cap;
        
        let a_inner = a % manifold.inner_cap;
        let a_outer = a % manifold.outer_cap;
        let b_inner = b % manifold.inner_cap;
        let b_outer = b % manifold.outer_cap;
        
        let prod_inner = (a_inner * b_inner) % manifold.inner_cap;
        let prod_outer = (a_outer * b_outer) % manifold.outer_cap;
        let k = k_elimination(prod_inner, prod_outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let result = reconstruct_from_k(prod_inner, k, manifold.inner_cap) % manifold.total_cap;
        
        if result == expected {
            passed += 1;
        } else {
            details.push_str(&format!("MUL FAIL: {}×{}={}, got {}\n", a, b, expected, result));
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let pass_rate = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G1: Algebraic Correctness".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([("pass_rate".to_string(), pass_rate)]),
    });
    
    battery.add_gate(QualityGate {
        name: "G1: Algebraic Correctness Rate".to_string(),
        threshold: 1.0,
        actual: pass_rate,
        passed: pass_rate >= 1.0,
        criticality: "BLOCKING",
    });
}

// =============================================================================
// GATE 2: K-ELIMINATION ACCURACY
// =============================================================================

fn test_gate2_k_elimination_accuracy(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    let mut k_values: Vec<i128> = Vec::new();
    
    // Test across multiple manifold sizes
    let manifolds = vec![
        DualManifold::small(),
        DualManifold::medium(),
    ];
    
    for manifold in &manifolds {
        // Random-ish test values covering the range
        let step = manifold.total_cap / 1000;
        let mut v = 0i128;
        while v < manifold.total_cap && total < 5000 {
            total += 1;
            let inner = v % manifold.inner_cap;
            let outer = v % manifold.outer_cap;
            let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
            let reconstructed = reconstruct_from_k(inner, k, manifold.inner_cap);
            
            k_values.push(k);
            
            if reconstructed % manifold.total_cap == v {
                passed += 1;
            } else {
                details.push_str(&format!("[{}] v={}: expected {}, got {}\n", 
                    manifold.name, v, v, reconstructed % manifold.total_cap));
            }
            
            v += step.max(1);
        }
    }
    
    // Compute k-value statistics
    let k_mean = k_values.iter().map(|&k| k as f64).sum::<f64>() / k_values.len() as f64;
    let k_max = *k_values.iter().max().unwrap_or(&0);
    let k_min = *k_values.iter().min().unwrap_or(&0);
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let pass_rate = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G2: K-Elimination Accuracy".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([
            ("pass_rate".to_string(), pass_rate),
            ("k_mean".to_string(), k_mean),
            ("k_max".to_string(), k_max as f64),
            ("k_min".to_string(), k_min as f64),
        ]),
    });
    
    battery.add_gate(QualityGate {
        name: "G2: K-Elimination Accuracy".to_string(),
        threshold: 1.0,
        actual: pass_rate,
        passed: pass_rate >= 1.0,
        criticality: "BLOCKING",
    });
}

// =============================================================================
// GATE 3: HOMOMORPHIC PROPERTIES
// =============================================================================

fn test_gate3_homomorphic_properties(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    let manifold = DualManifold::medium();
    let prime = 65537i128; // Working modulus for message space
    
    // Helper: encrypt (simplified - just compute residues)
    let encrypt = |m: i128| -> (i128, i128) {
        let m_mod = m % prime;
        (m_mod % manifold.inner_cap, m_mod % manifold.outer_cap)
    };
    
    // Helper: decrypt
    let decrypt = |inner: i128, outer: i128| -> i128 {
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        reconstruct_from_k(inner, k, manifold.inner_cap) % prime
    };
    
    // Test 3.1: Additive homomorphism
    println!("  Testing additive homomorphism...");
    let add_tests: Vec<(i128, i128)> = vec![
        (0, 0), (1, 1), (100, 200), (1000, 2000),
        (32768, 32768), // Near midpoint
        (65536, 1),     // Near wrap
    ];
    
    for (a, b) in &add_tests {
        total += 1;
        let (a_in, a_out) = encrypt(*a);
        let (b_in, b_out) = encrypt(*b);
        
        let sum_in = (a_in + b_in) % manifold.inner_cap;
        let sum_out = (a_out + b_out) % manifold.outer_cap;
        
        let decrypted = decrypt(sum_in, sum_out);
        let expected = (*a + *b) % prime;
        
        if decrypted == expected {
            passed += 1;
        } else {
            details.push_str(&format!("ADD: Dec(Enc({}) + Enc({})) = {}, expected {}\n",
                a, b, decrypted, expected));
        }
    }
    
    // Test 3.2: Multiplicative homomorphism
    println!("  Testing multiplicative homomorphism...");
    let mul_tests: Vec<(i128, i128)> = vec![
        (0, 1), (1, 1), (2, 3), (7, 11), (13, 17),
        (100, 100), (256, 256),
    ];
    
    for (a, b) in &mul_tests {
        total += 1;
        let (a_in, a_out) = encrypt(*a);
        let (b_in, b_out) = encrypt(*b);
        
        let prod_in = (a_in * b_in) % manifold.inner_cap;
        let prod_out = (a_out * b_out) % manifold.outer_cap;
        
        let decrypted = decrypt(prod_in, prod_out);
        let expected = (*a * *b) % prime;
        
        if decrypted == expected {
            passed += 1;
        } else {
            details.push_str(&format!("MUL: Dec(Enc({}) × Enc({})) = {}, expected {}\n",
                a, b, decrypted, expected));
        }
    }
    
    // Test 3.3: Mixed operations
    println!("  Testing mixed operations...");
    // (a + b) × c
    let mixed_tests: Vec<(i128, i128, i128)> = vec![
        (1, 2, 3),      // (1+2)*3 = 9
        (10, 20, 5),    // (10+20)*5 = 150
        (100, 100, 2),  // (100+100)*2 = 400
    ];
    
    for (a, b, c) in &mixed_tests {
        total += 1;
        let (a_in, a_out) = encrypt(*a);
        let (b_in, b_out) = encrypt(*b);
        let (c_in, c_out) = encrypt(*c);
        
        // (a + b)
        let sum_in = (a_in + b_in) % manifold.inner_cap;
        let sum_out = (a_out + b_out) % manifold.outer_cap;
        
        // × c
        let prod_in = (sum_in * c_in) % manifold.inner_cap;
        let prod_out = (sum_out * c_out) % manifold.outer_cap;
        
        let decrypted = decrypt(prod_in, prod_out);
        let expected = ((*a + *b) * *c) % prime;
        
        if decrypted == expected {
            passed += 1;
        } else {
            details.push_str(&format!("MIXED: Dec((Enc({}) + Enc({})) × Enc({})) = {}, expected {}\n",
                a, b, c, decrypted, expected));
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let pass_rate = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G3: Homomorphic Properties".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([("pass_rate".to_string(), pass_rate)]),
    });
    
    battery.add_gate(QualityGate {
        name: "G3: Homomorphic Correctness".to_string(),
        threshold: 1.0,
        actual: pass_rate,
        passed: pass_rate >= 1.0,
        criticality: "BLOCKING",
    });
}

// =============================================================================
// GATE 4: DEPTH STRESS TESTS
// =============================================================================

fn test_gate4_depth_stress(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut max_verified_depth = 0u64;
    let mut details = String::new();
    let manifold = DualManifold::medium();
    let prime = 65537i128;
    
    // Test 4.1: Repeated squaring chain
    println!("  Testing repeated squaring...");
    let mut inner = 2i128 % manifold.inner_cap;
    let mut outer = 2i128 % manifold.outer_cap;
    
    // Expected: 2^(2^n) mod 65537
    // By Fermat: 2^65536 ≡ 1 (mod 65537)
    // So after 16 squarings: 2^65536 ≡ 1
    let expected_values = [
        2, 4, 16, 256, 65536, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    ];
    
    let mut depth_k_progression: Vec<(u64, i128)> = Vec::new();
    
    for depth in 0..100 {
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let value = reconstruct_from_k(inner, k, manifold.inner_cap) % prime;
        
        depth_k_progression.push((depth, k));
        
        let expected = if depth < 20 { expected_values[depth as usize] } else { 1 };
        
        if value == expected {
            max_verified_depth = depth;
        } else {
            details.push_str(&format!("Depth {}: expected {}, got {}\n", depth, expected, value));
            break;
        }
        
        // Square
        inner = (inner * inner) % manifold.inner_cap;
        outer = (outer * outer) % manifold.outer_cap;
    }
    
    // Test 4.2: Addition chain
    println!("  Testing addition chain...");
    let mut add_depth_verified = 0u64;
    inner = 1;
    outer = 1;
    let mut expected_sum = 1i128;
    
    for depth in 0..1000 {
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let value = reconstruct_from_k(inner, k, manifold.inner_cap) % prime;
        
        if value == expected_sum % prime {
            add_depth_verified = depth;
        } else {
            details.push_str(&format!("Add depth {}: expected {}, got {}\n", depth, expected_sum % prime, value));
            break;
        }
        
        // Add 1
        inner = (inner + 1) % manifold.inner_cap;
        outer = (outer + 1) % manifold.outer_cap;
        expected_sum += 1;
    }
    
    // Test 4.3: Alternating add/multiply
    println!("  Testing alternating operations...");
    let mut alt_depth_verified = 0u64;
    inner = 2;
    outer = 2;
    let mut expected_val = 2i128;
    
    for depth in 0..50 {
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let value = reconstruct_from_k(inner, k, manifold.inner_cap) % prime;
        
        if value == expected_val % prime {
            alt_depth_verified = depth;
        } else {
            details.push_str(&format!("Alt depth {}: expected {}, got {}\n", depth, expected_val % prime, value));
            break;
        }
        
        if depth % 2 == 0 {
            // Add 3
            inner = (inner + 3) % manifold.inner_cap;
            outer = (outer + 3) % manifold.outer_cap;
            expected_val += 3;
        } else {
            // Multiply by 2
            inner = (inner * 2) % manifold.inner_cap;
            outer = (outer * 2) % manifold.outer_cap;
            expected_val *= 2;
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    
    // Collect k progression data
    let k_growth: Vec<f64> = depth_k_progression.iter()
        .map(|(_, k)| *k as f64)
        .collect();
    
    battery.add_result(TestResult {
        name: "G4: Depth Stress Tests".to_string(),
        passed: max_verified_depth >= 99,
        tests_run: 100 + 1000 + 50,
        tests_passed: (max_verified_depth + 1 + add_depth_verified + 1 + alt_depth_verified + 1) as u64,
        duration_ms: duration,
        details,
        data: HashMap::from([
            ("max_squaring_depth".to_string(), max_verified_depth as f64),
            ("max_addition_depth".to_string(), add_depth_verified as f64),
            ("max_alternating_depth".to_string(), alt_depth_verified as f64),
        ]),
    });
    
    battery.add_gate(QualityGate {
        name: "G4: Maximum Verified Depth".to_string(),
        threshold: 100.0,
        actual: max_verified_depth as f64,
        passed: max_verified_depth >= 100,
        criticality: "HIGH",
    });
    
    // Print k progression
    println!("\n  K-value progression (first 20 depths):");
    for (depth, k) in depth_k_progression.iter().take(20) {
        println!("    Depth {:3}: k = {:>12}", depth, k);
    }
}

// =============================================================================
// GATE 5: RANGE COVERAGE
// =============================================================================

fn test_gate5_range_coverage(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    let manifold = DualManifold::small();
    
    // Test EVERY value in the range (small manifold allows this)
    println!("  Testing full range coverage ({} values)...", manifold.total_cap);
    
    let mut v = 0i128;
    while v < manifold.total_cap {
        total += 1;
        let inner = v % manifold.inner_cap;
        let outer = v % manifold.outer_cap;
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let reconstructed = reconstruct_from_k(inner, k, manifold.inner_cap);
        
        if reconstructed % manifold.total_cap == v {
            passed += 1;
        } else if total - passed < 10 {
            // Only record first 10 failures
            details.push_str(&format!("v={}: expected {}, got {}\n", v, v, reconstructed % manifold.total_cap));
        }
        
        v += 1;
        
        // Progress indicator
        if v % 1000000 == 0 {
            println!("    Progress: {}/{}", v, manifold.total_cap);
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let coverage = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G5: Range Coverage".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([
            ("coverage".to_string(), coverage),
            ("total_range".to_string(), total as f64),
        ]),
    });
    
    battery.add_gate(QualityGate {
        name: "G5: Full Range Coverage".to_string(),
        threshold: 1.0,
        actual: coverage,
        passed: coverage >= 1.0,
        criticality: "HIGH",
    });
}

// =============================================================================
// GATE 6: EDGE CASES
// =============================================================================

fn test_gate6_edge_cases(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    let manifold = DualManifold::medium();
    
    println!("  Testing edge cases...");
    
    // Edge case 1: Zero
    total += 1;
    let k = k_elimination(0, 0, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(0, k, manifold.inner_cap) == 0 {
        passed += 1;
    } else {
        details.push_str("FAIL: Zero reconstruction\n");
    }
    
    // Edge case 2: Max inner
    total += 1;
    let v = manifold.inner_cap - 1;
    let inner = v % manifold.inner_cap;
    let outer = v % manifold.outer_cap;
    let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(inner, k, manifold.inner_cap) % manifold.total_cap == v {
        passed += 1;
    } else {
        details.push_str("FAIL: Max inner reconstruction\n");
    }
    
    // Edge case 3: Max outer
    total += 1;
    let v = manifold.outer_cap - 1;
    let inner = v % manifold.inner_cap;
    let outer = v % manifold.outer_cap;
    let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(inner, k, manifold.inner_cap) % manifold.total_cap == v {
        passed += 1;
    } else {
        details.push_str("FAIL: Max outer reconstruction\n");
    }
    
    // Edge case 4: Max total - 1
    total += 1;
    let v = manifold.total_cap - 1;
    let inner = v % manifold.inner_cap;
    let outer = v % manifold.outer_cap;
    let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(inner, k, manifold.inner_cap) % manifold.total_cap == v {
        passed += 1;
    } else {
        details.push_str("FAIL: Max total-1 reconstruction\n");
    }
    
    // Edge case 5: Inner wrap boundary
    total += 1;
    let v = manifold.inner_cap;
    let inner = v % manifold.inner_cap;
    let outer = v % manifold.outer_cap;
    let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(inner, k, manifold.inner_cap) % manifold.total_cap == v {
        passed += 1;
    } else {
        details.push_str("FAIL: Inner wrap boundary\n");
    }
    
    // Edge case 6: Outer wrap boundary  
    total += 1;
    let v = manifold.outer_cap;
    let inner = v % manifold.inner_cap;
    let outer = v % manifold.outer_cap;
    let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(inner, k, manifold.inner_cap) % manifold.total_cap == v {
        passed += 1;
    } else {
        details.push_str("FAIL: Outer wrap boundary\n");
    }
    
    // Edge case 7: Add causing inner wrap
    total += 1;
    let a = manifold.inner_cap - 5;
    let b = 10i128;
    let sum_expected = (a + b) % manifold.total_cap;
    let sum_inner = ((a % manifold.inner_cap) + (b % manifold.inner_cap)) % manifold.inner_cap;
    let sum_outer = ((a % manifold.outer_cap) + (b % manifold.outer_cap)) % manifold.outer_cap;
    let k = k_elimination(sum_inner, sum_outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    if reconstruct_from_k(sum_inner, k, manifold.inner_cap) % manifold.total_cap == sum_expected {
        passed += 1;
    } else {
        details.push_str(&format!("FAIL: Add wrap inner: {}+{}={}\n", a, b, sum_expected));
    }
    
    // Edge case 8: Multiply causing both wraps
    total += 1;
    let a = manifold.inner_cap + 1;
    let b = manifold.outer_cap + 1;
    let prod_expected = (a * b) % manifold.total_cap;
    let prod_inner = ((a % manifold.inner_cap) * (b % manifold.inner_cap)) % manifold.inner_cap;
    let prod_outer = ((a % manifold.outer_cap) * (b % manifold.outer_cap)) % manifold.outer_cap;
    let k = k_elimination(prod_inner, prod_outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    let result = reconstruct_from_k(prod_inner, k, manifold.inner_cap) % manifold.total_cap;
    if result == prod_expected {
        passed += 1;
    } else {
        details.push_str(&format!("FAIL: Mul wrap both: {}×{}={}, got {}\n", a, b, prod_expected, result));
    }
    
    // Edge case 9: Power of 2 boundaries
    for pow in 0..20 {
        total += 1;
        let v = 1i128 << pow;
        if v >= manifold.total_cap { break; }
        let inner = v % manifold.inner_cap;
        let outer = v % manifold.outer_cap;
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        if reconstruct_from_k(inner, k, manifold.inner_cap) % manifold.total_cap == v {
            passed += 1;
        } else {
            details.push_str(&format!("FAIL: 2^{} = {}\n", pow, v));
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let pass_rate = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G6: Edge Cases".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([("pass_rate".to_string(), pass_rate)]),
    });
    
    battery.add_gate(QualityGate {
        name: "G6: Edge Case Pass Rate".to_string(),
        threshold: 1.0,
        actual: pass_rate,
        passed: pass_rate >= 1.0,
        criticality: "BLOCKING",
    });
}

// =============================================================================
// GATE 7: PERFORMANCE METRICS
// =============================================================================

fn test_gate7_performance(battery: &mut TestBattery) {
    let manifold = DualManifold::medium();
    
    println!("  Benchmarking K-Elimination...");
    
    // Warmup
    for _ in 0..1000 {
        let _ = k_elimination(12345, 67890, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    }
    
    // Benchmark K-Elimination
    let iterations = 100000u64;
    let start = Instant::now();
    for i in 0..iterations {
        let _ = k_elimination(
            i as i128 % manifold.inner_cap,
            i as i128 % manifold.outer_cap,
            manifold.inner_cap,
            manifold.inner_inv_outer,
            manifold.outer_cap
        );
    }
    let k_elim_duration = start.elapsed();
    let k_elim_ops_per_sec = iterations as f64 / k_elim_duration.as_secs_f64();
    
    // Benchmark full cycle (compute residues + K-elimination + reconstruction)
    println!("  Benchmarking full cycle...");
    let start = Instant::now();
    for i in 0..iterations {
        let v = i as i128 * 1234567;
        let inner = v % manifold.inner_cap;
        let outer = v % manifold.outer_cap;
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let _ = reconstruct_from_k(inner, k, manifold.inner_cap);
    }
    let full_duration = start.elapsed();
    let full_ops_per_sec = iterations as f64 / full_duration.as_secs_f64();
    
    // Benchmark homomorphic multiplication
    println!("  Benchmarking homomorphic multiplication...");
    let mut inner = 2i128;
    let mut outer = 2i128;
    let start = Instant::now();
    for _ in 0..iterations {
        inner = (inner * inner) % manifold.inner_cap;
        outer = (outer * outer) % manifold.outer_cap;
        let _ = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
    }
    let hom_mul_duration = start.elapsed();
    let hom_mul_ops_per_sec = iterations as f64 / hom_mul_duration.as_secs_f64();
    
    // Benchmark Garner reconstruction
    println!("  Benchmarking Garner reconstruction...");
    let moduli = vec![7i128, 11, 13, 17, 19, 23, 29, 31];
    let start = Instant::now();
    for i in 0..10000 {
        let v = i as i128 * 12345;
        let residues: Vec<i128> = moduli.iter().map(|&m| v % m).collect();
        let _ = garner_reconstruction(&residues, &moduli);
    }
    let garner_duration = start.elapsed();
    let garner_ops_per_sec = 10000.0 / garner_duration.as_secs_f64();
    
    let total_duration = k_elim_duration + full_duration + hom_mul_duration + garner_duration;
    
    battery.add_result(TestResult {
        name: "G7: Performance Metrics".to_string(),
        passed: k_elim_ops_per_sec >= 10000.0,
        tests_run: iterations * 3 + 10000,
        tests_passed: iterations * 3 + 10000,
        duration_ms: total_duration.as_secs_f64() * 1000.0,
        details: format!(
            "K-Elim: {:.0} ops/s\nFull cycle: {:.0} ops/s\nHom mul: {:.0} ops/s\nGarner: {:.0} ops/s",
            k_elim_ops_per_sec, full_ops_per_sec, hom_mul_ops_per_sec, garner_ops_per_sec
        ),
        data: HashMap::from([
            ("k_elim_ops_per_sec".to_string(), k_elim_ops_per_sec),
            ("full_cycle_ops_per_sec".to_string(), full_ops_per_sec),
            ("hom_mul_ops_per_sec".to_string(), hom_mul_ops_per_sec),
            ("garner_ops_per_sec".to_string(), garner_ops_per_sec),
        ]),
    });
    
    battery.add_gate(QualityGate {
        name: "G7: K-Elimination Throughput".to_string(),
        threshold: 10000.0,
        actual: k_elim_ops_per_sec,
        passed: k_elim_ops_per_sec >= 10000.0,
        criticality: "MEDIUM",
    });
    
    battery.add_gate(QualityGate {
        name: "G7: Homomorphic Mul Throughput".to_string(),
        threshold: 10000.0,
        actual: hom_mul_ops_per_sec,
        passed: hom_mul_ops_per_sec >= 10000.0,
        criticality: "MEDIUM",
    });
    
    println!("\n  Performance Results:");
    println!("    K-Elimination:      {:>12.0} ops/sec", k_elim_ops_per_sec);
    println!("    Full cycle:         {:>12.0} ops/sec", full_ops_per_sec);
    println!("    Homomorphic mul:    {:>12.0} ops/sec", hom_mul_ops_per_sec);
    println!("    Garner (8 moduli):  {:>12.0} ops/sec", garner_ops_per_sec);
}

// =============================================================================
// GATE 8: STATISTICAL VALIDATION
// =============================================================================

fn test_gate8_statistical_validation(battery: &mut TestBattery) {
    let start = Instant::now();
    let manifold = DualManifold::medium();
    
    println!("  Collecting k-value distribution...");
    
    // Collect k values across the range
    let sample_size = 100000usize;
    let mut k_values: Vec<i128> = Vec::with_capacity(sample_size);
    let step = manifold.total_cap / sample_size as i128;
    
    let mut v = 0i128;
    while k_values.len() < sample_size && v < manifold.total_cap {
        let inner = v % manifold.inner_cap;
        let outer = v % manifold.outer_cap;
        let k = k_elimination(inner, outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        k_values.push(k);
        v += step;
    }
    
    // Compute statistics
    let n = k_values.len() as f64;
    let mean = k_values.iter().map(|&k| k as f64).sum::<f64>() / n;
    let variance = k_values.iter().map(|&k| {
        let diff = k as f64 - mean;
        diff * diff
    }).sum::<f64>() / n;
    let std_dev = variance.sqrt();
    
    let min_k = *k_values.iter().min().unwrap_or(&0);
    let max_k = *k_values.iter().max().unwrap_or(&0);
    
    // Theoretical: k should be uniformly distributed in [0, outer_cap)
    // Expected mean = outer_cap / 2
    // Expected variance = outer_cap^2 / 12
    let expected_mean = manifold.outer_cap as f64 / 2.0;
    let expected_variance = (manifold.outer_cap as f64).powi(2) / 12.0;
    let expected_std_dev = expected_variance.sqrt();
    
    let mean_error = (mean - expected_mean).abs() / expected_mean;
    let std_dev_error = (std_dev - expected_std_dev).abs() / expected_std_dev;
    
    // Simple χ² test: bucket k values and compare to uniform distribution
    let num_buckets = 100;
    let bucket_size = manifold.outer_cap / num_buckets as i128;
    let mut buckets = vec![0u64; num_buckets];
    
    for &k in &k_values {
        let bucket = (k / bucket_size.max(1)) as usize;
        if bucket < num_buckets {
            buckets[bucket] += 1;
        }
    }
    
    let expected_per_bucket = n / num_buckets as f64;
    let chi_squared: f64 = buckets.iter()
        .map(|&count| {
            let diff = count as f64 - expected_per_bucket;
            diff * diff / expected_per_bucket
        })
        .sum();
    
    // Chi-squared critical value for 99 df at 0.05 significance ≈ 123.2
    let chi_squared_threshold = 150.0; // Being generous
    let chi_squared_passed = chi_squared < chi_squared_threshold;
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    
    battery.add_result(TestResult {
        name: "G8: Statistical Validation".to_string(),
        passed: mean_error < 0.1 && chi_squared_passed,
        tests_run: sample_size as u64,
        tests_passed: if chi_squared_passed { sample_size as u64 } else { 0 },
        duration_ms: duration,
        details: format!(
            "k-value stats:\n  Mean: {:.2} (expected {:.2}, error {:.2}%)\n  StdDev: {:.2} (expected {:.2})\n  Range: [{}, {}]\n  χ²: {:.2} (threshold {})",
            mean, expected_mean, mean_error * 100.0,
            std_dev, expected_std_dev,
            min_k, max_k,
            chi_squared, chi_squared_threshold
        ),
        data: HashMap::from([
            ("k_mean".to_string(), mean),
            ("k_std_dev".to_string(), std_dev),
            ("k_min".to_string(), min_k as f64),
            ("k_max".to_string(), max_k as f64),
            ("chi_squared".to_string(), chi_squared),
            ("mean_error_pct".to_string(), mean_error * 100.0),
        ]),
    });
    
    battery.add_gate(QualityGate {
        name: "G8: K-value Uniformity (χ²)".to_string(),
        threshold: chi_squared_threshold,
        actual: chi_squared,
        passed: chi_squared_passed,
        criticality: "LOW",
    });
    
    println!("\n  K-value Distribution:");
    println!("    Sample size:    {}", sample_size);
    println!("    Mean:           {:.2} (expected {:.2})", mean, expected_mean);
    println!("    Std Dev:        {:.2} (expected {:.2})", std_dev, expected_std_dev);
    println!("    Range:          [{}, {}]", min_k, max_k);
    println!("    χ² statistic:   {:.2} (threshold {})", chi_squared, chi_squared_threshold);
}

// =============================================================================
// GATE 9: GARNER EQUIVALENCE
// =============================================================================

fn test_gate9_garner_equivalence(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    
    println!("  Testing K-Elimination ↔ Garner equivalence...");
    
    // Test with various moduli configurations
    let test_configs: Vec<Vec<i128>> = vec![
        vec![3, 5],
        vec![7, 11],
        vec![3, 5, 7],
        vec![7, 11, 13],
        vec![3, 5, 7, 11],
        vec![7, 11, 13, 17],
        vec![3, 5, 7, 11, 13],
        vec![7, 11, 13, 17, 19, 23],
    ];
    
    for moduli in &test_configs {
        let capacity: i128 = moduli.iter().product();
        let test_values: Vec<i128> = vec![
            0, 1, capacity / 2, capacity - 1,
            12345 % capacity, 67890 % capacity,
        ];
        
        for &v in &test_values {
            total += 1;
            
            // Compute residues
            let residues: Vec<i128> = moduli.iter().map(|&m| v % m).collect();
            
            // Reconstruct using Garner
            let garner_result = garner_reconstruction(&residues, moduli);
            
            // For 2 moduli, also test K-Elimination
            if moduli.len() == 2 {
                let inner_cap = moduli[0];
                let outer_cap = moduli[1];
                let inner_inv_outer = mod_inverse(inner_cap % outer_cap, outer_cap).unwrap();
                let k = k_elimination(residues[0], residues[1], inner_cap, inner_inv_outer, outer_cap);
                let k_elim_result = reconstruct_from_k(residues[0], k, inner_cap);
                
                if k_elim_result != garner_result {
                    details.push_str(&format!(
                        "MISMATCH: v={}, moduli={:?}, Garner={}, K-Elim={}\n",
                        v, moduli, garner_result, k_elim_result
                    ));
                    continue;
                }
            }
            
            if garner_result % capacity == v {
                passed += 1;
            } else {
                details.push_str(&format!(
                    "FAIL: v={}, moduli={:?}, got {}\n",
                    v, moduli, garner_result
                ));
            }
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let pass_rate = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G9: Garner Equivalence".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([("pass_rate".to_string(), pass_rate)]),
    });
    
    battery.add_gate(QualityGate {
        name: "G9: K-Elim ↔ Garner Equivalence".to_string(),
        threshold: 1.0,
        actual: pass_rate,
        passed: pass_rate >= 1.0,
        criticality: "BLOCKING",
    });
}

// =============================================================================
// GATE 10: FERMAT LITTLE THEOREM VALIDATION
// =============================================================================

fn test_gate10_fermat_validation(battery: &mut TestBattery) {
    let start = Instant::now();
    let mut passed = 0u64;
    let mut total = 0u64;
    let mut details = String::new();
    let manifold = DualManifold::medium();
    
    // Test primes for Fermat's Little Theorem
    let test_primes: Vec<i128> = vec![5, 7, 11, 13, 17, 19, 23, 29, 31, 65537];
    
    println!("  Validating Fermat's Little Theorem through homomorphic ops...");
    
    for &p in &test_primes {
        // For prime p, a^(p-1) ≡ 1 (mod p) for gcd(a,p) = 1
        // Test with a = 2
        let a = 2i128;
        
        // Compute 2^(p-1) mod p homomorphically via repeated squaring
        let mut inner = a % manifold.inner_cap;
        let mut outer = a % manifold.outer_cap;
        
        let mut exp = p - 1;
        let mut result_inner = 1i128;
        let mut result_outer = 1i128;
        
        while exp > 0 {
            if exp & 1 == 1 {
                result_inner = (result_inner * inner) % manifold.inner_cap;
                result_outer = (result_outer * outer) % manifold.outer_cap;
            }
            inner = (inner * inner) % manifold.inner_cap;
            outer = (outer * outer) % manifold.outer_cap;
            exp >>= 1;
        }
        
        let k = k_elimination(result_inner, result_outer, manifold.inner_cap, manifold.inner_inv_outer, manifold.outer_cap);
        let reconstructed = reconstruct_from_k(result_inner, k, manifold.inner_cap);
        let result_mod_p = reconstructed % p;
        
        total += 1;
        if result_mod_p == 1 {
            passed += 1;
        } else {
            details.push_str(&format!("FAIL: 2^{} mod {} = {} (expected 1)\n", p-1, p, result_mod_p));
        }
    }
    
    let duration = start.elapsed().as_secs_f64() * 1000.0;
    let pass_rate = passed as f64 / total as f64;
    
    battery.add_result(TestResult {
        name: "G10: Fermat's Little Theorem".to_string(),
        passed: passed == total,
        tests_run: total,
        tests_passed: passed,
        duration_ms: duration,
        details,
        data: HashMap::from([("pass_rate".to_string(), pass_rate)]),
    });
    
    battery.add_gate(QualityGate {
        name: "G10: FLT Validation".to_string(),
        threshold: 1.0,
        actual: pass_rate,
        passed: pass_rate >= 1.0,
        criticality: "HIGH",
    });
}

// =============================================================================
// MAIN TEST RUNNER
// =============================================================================

fn main() {
    println!("\n");
    println!("╔══════════════════════════════════════════════════════════════════════════════╗");
    println!("║                                                                              ║");
    println!("║         CLOCKWORK-WASSAN FHE: COMPREHENSIVE TEST BATTERY                    ║");
    println!("║                                                                              ║");
    println!("║         \"I love the smell of napalm in the morning\"                         ║");
    println!("║                                                                              ║");
    println!("╚══════════════════════════════════════════════════════════════════════════════╝\n");
    
    let mut battery = TestBattery::new();
    let total_start = Instant::now();
    
    // Run all test gates
    println!("═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 1: Algebraic Correctness");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate1_algebraic_correctness(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 2: K-Elimination Accuracy");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate2_k_elimination_accuracy(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 3: Homomorphic Properties");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate3_homomorphic_properties(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 4: Depth Stress Tests");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate4_depth_stress(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 5: Range Coverage");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate5_range_coverage(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 6: Edge Cases");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate6_edge_cases(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 7: Performance Metrics");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate7_performance(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 8: Statistical Validation");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate8_statistical_validation(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 9: Garner Equivalence");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate9_garner_equivalence(&mut battery);
    
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("GATE 10: Fermat's Little Theorem Validation");
    println!("───────────────────────────────────────────────────────────────────────────────");
    test_gate10_fermat_validation(&mut battery);
    
    let total_duration = total_start.elapsed();
    battery.total_duration_ms = total_duration.as_secs_f64() * 1000.0;
    
    // Print summary
    battery.print_summary();
    
    // Export data for analysis
    println!("\n═══════════════════════════════════════════════════════════════════════════════");
    println!("COLLECTED DATA:");
    println!("───────────────────────────────────────────────────────────────────────────────");
    for result in &battery.results {
        println!("\n{}:", result.name);
        for (key, value) in &result.data {
            println!("  {}: {:.6}", key, value);
        }
    }
}
